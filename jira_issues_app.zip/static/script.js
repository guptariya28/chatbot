// Search box: hide table rows that don't contain the typed text
const search = document.getElementById("search");

search.addEventListener("input", () => {
  const text = search.value.toLowerCase();
  let shown = 0;

  document.querySelectorAll("#issues tbody tr").forEach(row => {
    const match = row.innerText.toLowerCase().includes(text);
    row.style.display = match ? "" : "none";
    if (match) shown++;
  });

  document.getElementById("count").innerText = shown;
});
