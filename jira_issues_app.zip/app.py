import truststore
truststore.inject_into_ssl()  # use the Windows certificate store (corporate CA)

import os, requests
import pandas as pd
from dotenv import load_dotenv
from flask import Flask, render_template

load_dotenv()

SITE = "https://mercedes-benz-pace.atlassian.net"
AUTH = (os.environ["ATLASSIAN_EMAIL"], os.environ["ATLASSIAN_API_TOKEN"])

PROJECTS = ["FPM", "SAC", "TAFM"]
JQL = f"project in ({', '.join(PROJECTS)}) ORDER BY created DESC"
FIELDS = "summary,issuetype,status,priority,reporter,assignee,created,updated,duedate,project"

app = Flask(__name__)


@app.route("/")
def index():
    url = f"{SITE}/rest/api/3/search/jql"
    headers = {"Accept": "application/json"}
    params = {"jql": JQL, "fields": FIELDS, "maxResults": 100}

    # 1. Get all issues, page by page
    issues = []
    while True:
        r = requests.get(url, headers=headers, auth=AUTH, params=params)
        r.raise_for_status()
        data = r.json()
        issues += data["issues"]
        if data.get("isLast", True):
            break
        params["nextPageToken"] = data["nextPageToken"]

    # 2. Keep only the important fields
    rows = []
    for issue in issues:
        f = issue["fields"]
        rows.append({
            "Key": issue["key"],
            "Summary": f["summary"],
            "Type": f["issuetype"]["name"],
            "Status": f["status"]["name"],
            "Priority": (f["priority"] or {}).get("name", ""),
            "Project": f["project"]["key"],
            "Reporter": (f["reporter"] or {}).get("displayName", ""),
            "Assignee": (f["assignee"] or {}).get("displayName", "Unassigned"),
            "Created": f["created"][:10],
            "Updated": f["updated"][:10],
            "Due date": f["duedate"] or "",
            "Link": f"{SITE}/browse/{issue['key']}",
        })

    # 3. Turn them into an HTML table
    df = pd.DataFrame(rows)
    table = df.to_html(index=False, border=0, render_links=True, table_id="issues")
    return render_template("index.html", table=table, count=len(df))


if __name__ == "__main__":
    app.run(port=5000, debug=True)
