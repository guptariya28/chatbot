// ============================================================
// register.js - makes the Demand register work like Excel
//
//   1. ▼ in a header  -> filter menu (sort, search, tick values)
//   2. Click a cell   -> edit it (dropdown or type-in box)
//   3. Save bar       -> sends the changed cells to Python (/register/save)
//
// Python still does the saving, the permissions and the change log.
// This file only changes what you see in the browser.
// ============================================================


// ---------- What we remember while the page is open ----------

let columnFilters = {};   // column number -> list of ticked values,  e.g. { "2": ["fg", "controlling"] }
let filterLabels = {};    // column number -> the same values as shown,  e.g. { "2": ["FG", "Controlling"] }
let menuLabels = {};      // value -> label, for the menu that is open now
let changes = {};         // "id_column" -> { id, col, row, oldValue, newValue }
let openColumn = null;    // the column whose filter menu is open
let searchText = "";      // text in the "Search in table" box


// ---------- Small helpers ----------

// All table rows (the <tr> elements in the body)
function getRows() {
  return Array.from(document.querySelectorAll("#sheet tbody tr"));
}

// One cell of a row, found by its column number
function getCell(row, col) {
  return row.querySelector('td[data-col="' + col + '"]');
}

// The value we filter on: small letters, and "(blanks)" for an empty cell
function filterValue(cell) {
  const value = cell.dataset.value.trim();
  if (value === "") {
    return "(blanks)";
  }
  return value.toLowerCase();
}

// Is this column a number column? (Development, Functional, Total ...)
function isNumberColumn(col) {
  const header = document.querySelector('.name-row th[data-col="' + col + '"]');
  return header.dataset.type === "number";
}


// ============================================================
// 1. Filters
// ============================================================

// Shows or hides every row, using the column filters and the search box
function applyAllFilters() {
  let shown = 0;

  for (const row of getRows()) {
    let keep = true;

    // Column filters: the value must be one of the ticked values
    for (const col in columnFilters) {
      const cell = getCell(row, col);
      if (!columnFilters[col].includes(filterValue(cell))) {
        keep = false;
      }
    }

    // Search box: the text must be somewhere in the row
    if (keep && searchText !== "") {
      if (!row.textContent.toLowerCase().includes(searchText)) {
        keep = false;
      }
    }

    row.hidden = !keep;
    if (keep) {
      shown = shown + 1;
    }
  }

  document.getElementById("shown-count").textContent = shown;
  document.getElementById("no-rows").hidden = (shown > 0);
  showFilterChips();
  markFilteredHeaders();
}

// One blue chip per filtered column:  "Topic Group: FG, Controlling ✕"
function showFilterChips() {
  const box = document.getElementById("filter-chips");
  box.innerHTML = "";

  for (const col in columnFilters) {
    const chip = document.createElement("span");
    chip.className = "filter-chip";
    chip.textContent = COLUMN_NAMES[col] + ": " + filterLabels[col].join(", ") + "  ✕";
    chip.title = "Remove this filter";
    chip.onclick = function () {
      delete columnFilters[col];
      applyAllFilters();
    };
    box.appendChild(chip);
  }
}

// Filtered columns get a highlighted header and ▼ button
function markFilteredHeaders() {
  for (const header of document.querySelectorAll(".name-row th[data-col]")) {
    const filtered = header.dataset.col in columnFilters;
    header.classList.toggle("filtered", filtered);
  }
}

// Opens the filter menu under the ▼ button that was clicked
function openFilterMenu(button) {
  openColumn = button.dataset.col;

  // Count every value in this column (like Excel's list of values)
  const counts = {};
  const labels = {};
  for (const row of getRows()) {
    const cell = getCell(row, openColumn);
    const key = filterValue(cell);
    if (!(key in counts)) {
      counts[key] = 0;
      labels[key] = cell.dataset.value.trim() || "(Blanks)";
    }
    counts[key] = counts[key] + 1;
  }

  // Sort the values A to Z (numbers by size), blanks last
  let keys = Object.keys(counts);
  keys.sort(function (a, b) {
    if (a === "(blanks)") return 1;
    if (b === "(blanks)") return -1;
    if (isNumberColumn(openColumn)) return parseFloat(a) - parseFloat(b);
    return a.localeCompare(b);
  });

  // Build the list of checkboxes
  const list = document.getElementById("menu-values");
  let html = '<label class="menu-value select-all"><input type="checkbox" id="select-all" onchange="tickAll(this.checked)"> (Select All)</label>';
  for (const key of keys) {
    let ticked = true;
    if (openColumn in columnFilters) {
      ticked = columnFilters[openColumn].includes(key);
    }
    html += '<label class="menu-value"><input type="checkbox" class="value-box" value="' + escapeText(key) + '"'
          + (ticked ? " checked" : "") + ' onchange="updateSelectAll()"> '
          + escapeText(labels[key]) + '<em>' + counts[key] + '</em></label>';
  }
  list.innerHTML = html;
  menuLabels = labels;
  updateSelectAll();

  document.getElementById("menu-column-name").textContent = COLUMN_NAMES[openColumn];
  document.getElementById("menu-search").value = "";

  // Put the menu just under the button (but never outside the screen)
  const menu = document.getElementById("filter-menu");
  const place = button.getBoundingClientRect();
  menu.hidden = false;
  let left = place.right - menu.offsetWidth;
  if (left < 8) left = 8;
  menu.style.left = left + "px";
  menu.style.top = (place.bottom + 4) + "px";
}

function closeFilterMenu() {
  document.getElementById("filter-menu").hidden = true;
  openColumn = null;
}

// (Select All) ticks or unticks every visible value
function tickAll(checked) {
  for (const box of document.querySelectorAll(".value-box")) {
    if (!box.parentElement.hidden) {
      box.checked = checked;
    }
  }
}

// (Select All) shows ✓ when all are ticked, – when only some are ticked
function updateSelectAll() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = boxes.filter(function (box) { return box.checked; }).length;
  const selectAll = document.getElementById("select-all");
  selectAll.checked = (ticked === boxes.length);
  selectAll.indeterminate = (ticked > 0 && ticked < boxes.length);
}

// The search box inside the menu hides values that don't match
function searchMenuValues() {
  const text = document.getElementById("menu-search").value.toLowerCase();
  for (const box of document.querySelectorAll(".value-box")) {
    box.parentElement.hidden = !box.value.includes(text);
  }
}

// OK button: remember the ticked values for this column
function applyColumnFilter() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = [];
  const tickedLabels = [];
  for (const box of boxes) {
    if (box.checked) {
      ticked.push(box.value);
      tickedLabels.push(menuLabels[box.value]);
    }
  }

  if (ticked.length === boxes.length) {
    delete columnFilters[openColumn];     // everything ticked = no filter
  } else {
    columnFilters[openColumn] = ticked;
    filterLabels[openColumn] = tickedLabels;
  }
  closeFilterMenu();
  applyAllFilters();
}

function clearColumnFilter() {
  delete columnFilters[openColumn];
  closeFilterMenu();
  applyAllFilters();
}

// Sort A to Z (direction 1) or Z to A (direction -1)
function sortColumn(direction) {
  const col = openColumn;
  const number = isNumberColumn(col);
  const rows = getRows();

  rows.sort(function (rowA, rowB) {
    const a = getCell(rowA, col).dataset.value.trim();
    const b = getCell(rowB, col).dataset.value.trim();
    if (a === "" && b !== "") return 1;      // blanks always at the bottom
    if (b === "" && a !== "") return -1;
    if (number) return (parseFloat(a) - parseFloat(b)) * direction;
    return a.localeCompare(b) * direction;
  });

  const body = document.querySelector("#sheet tbody");
  for (const row of rows) {
    body.appendChild(row);                   // moving a row puts it at the end, so this re-orders them
  }
  closeFilterMenu();
}

// Makes text safe to put inside HTML
function escapeText(text) {
  const box = document.createElement("span");
  box.textContent = text;
  return box.innerHTML.replace(/"/g, "&quot;");
}


// ============================================================
// 2. Editing a cell
// ============================================================

// Click on an editable cell -> show a dropdown or a type-in box in it
function startEdit(cell) {
  if (cell.querySelector("input, select")) {
    return;                                  // already editing this cell
  }
  const col = cell.dataset.col;
  const current = cell.dataset.value;

  // Remember the value from the Excel, the first time this cell is edited
  if (cell.dataset.original === undefined) {
    cell.dataset.original = current;
  }

  let box;
  if (col in DROPDOWN_VALUES) {
    // A dropdown with every value used in this column
    box = document.createElement("select");
    box.appendChild(new Option("(blank)", ""));
    let found = (current === "");
    for (const value of DROPDOWN_VALUES[col]) {
      box.appendChild(new Option(value, value));
      if (value.toLowerCase() === current.toLowerCase()) {
        found = true;
      }
    }
    if (!found) {
      box.appendChild(new Option(current, current));
    }
    // pick the current value (Excel spelling can differ in capitals)
    for (const option of box.options) {
      if (option.value.toLowerCase() === current.toLowerCase()) {
        box.value = option.value;
      }
    }
    box.onchange = function () { finishEdit(cell, box.value); };
  } else {
    // A type-in box (numbers only for the man-days columns)
    box = document.createElement("input");
    box.type = isNumberColumn(col) ? "number" : "text";
    if (box.type === "number") {
      box.step = "any";
      box.min = "0";
    }
    box.value = current;
  }

  box.className = "cell-editor";
  box.onblur = function () { finishEdit(cell, box.value); };
  box.onkeydown = function (event) {
    if (event.key === "Enter") box.blur();                          // Enter = done
    if (event.key === "Escape") finishEdit(cell, cell.dataset.value); // Esc = undo typing
  };

  cell.classList.add("editing");
  cell.innerHTML = "";
  cell.appendChild(box);
  box.focus();
}

// Puts the new value in the cell and remembers the change
function finishEdit(cell, newValue) {
  if (!cell.classList.contains("editing")) {
    return;                                  // already finished (blur after change)
  }
  cell.classList.remove("editing");

  newValue = String(newValue).trim();
  cell.dataset.value = newValue;

  const row = cell.parentElement;
  const col = cell.dataset.col;
  const key = row.dataset.id + "_" + col;
  const oldValue = cell.dataset.original;

  // Did it really change? (numbers: 30 and 30.0 are the same)
  let changed = (newValue !== oldValue);
  if (isNumberColumn(col)) {
    changed = (Number(newValue || 0) !== Number(oldValue || 0));
  }

  if (changed) {
    changes[key] = {
      id: row.dataset.id,
      col: col,
      row: row.querySelector(".row-number").textContent,
      oldValue: oldValue,
      newValue: newValue,
    };
  } else {
    delete changes[key];
  }

  showCellValue(cell, changed ? oldValue : null);

  // Development or Functional changed -> Total Effort = Development + Functional (like the Excel formula)
  if (col == FORMULA_COLUMNS.dev || col == FORMULA_COLUMNS.func) {
    updateTotal(row);
  }
  updateSaveBar();
}

// Shows the value in the cell. A changed cell is yellow and shows the old value.
function showCellValue(cell, oldValue) {
  cell.innerHTML = "";
  const value = cell.dataset.value;

  if (value === "") {
    cell.innerHTML = '<span class="empty">—</span>';
  } else {
    cell.textContent = value;
  }

  cell.classList.toggle("changed", oldValue !== null);
  if (oldValue !== null) {
    const was = document.createElement("i");
    was.className = "was";
    was.textContent = "was " + (oldValue === "" ? "blank" : oldValue);
    cell.appendChild(was);
  }
}

// Recalculates the Total Effort cell of one row (only if Total is shown)
function updateTotal(row) {
  const devCell = getCell(row, FORMULA_COLUMNS.dev);
  const funcCell = getCell(row, FORMULA_COLUMNS.func);
  const totalCell = getCell(row, FORMULA_COLUMNS.total);
  if (!devCell || !funcCell || !totalCell) {
    return;
  }
  const total = Number(devCell.dataset.value || 0) + Number(funcCell.dataset.value || 0);
  totalCell.dataset.value = String(total);
  totalCell.textContent = total;
}


// ============================================================
// 3. Save bar
// ============================================================

// Shows how many cells changed, and puts one hidden box per change in the form
function updateSaveBar() {
  const list = Object.values(changes);
  const form = document.getElementById("save-form");
  form.hidden = (list.length === 0);

  document.getElementById("change-count").textContent =
    list.length + (list.length === 1 ? " unsaved change" : " unsaved changes");

  // A short summary:  "Row 6: Development 30 → 35 · Row 8: Business Confirmation"
  const parts = [];
  for (const change of list) {
    let text = "Row " + change.row + ": " + COLUMN_NAMES[change.col];
    if (isNumberColumn(change.col)) {
      text += " " + (change.oldValue || 0) + " → " + (change.newValue || 0);
    }
    parts.push(text);
  }
  document.getElementById("change-list").textContent = parts.join(" · ");

  // The boxes Python reads:  cell_<id>_<column number>
  const boxes = document.getElementById("save-boxes");
  boxes.innerHTML = "";
  for (const change of list) {
    const box = document.createElement("input");
    box.type = "hidden";
    box.name = "cell_" + change.id + "_" + change.col;
    box.value = change.newValue;
    boxes.appendChild(box);
  }
}

// Discard: load the page again (nothing was saved yet)
function discardChanges() {
  changes = {};
  location.reload();
}


// ============================================================
// Connect the functions to clicks and typing
// ============================================================

// Click a ▼ button -> open its menu.  Click outside the menu -> close it.
document.addEventListener("click", function (event) {
  const button = event.target.closest(".filter-button");
  if (button) {
    openFilterMenu(button);
    return;
  }
  if (!event.target.closest("#filter-menu")) {
    closeFilterMenu();
  }
});

// Click an editable cell -> edit it
document.querySelector("#sheet tbody").addEventListener("click", function (event) {
  const cell = event.target.closest("td.editable");
  if (cell) {
    startEdit(cell);
  }
});

// Type in "Search in table" -> filter the rows
document.getElementById("table-search").addEventListener("input", function (event) {
  searchText = event.target.value.toLowerCase().trim();
  applyAllFilters();
});

// Saving: no warning.  Leaving the page with unsaved changes: ask first.
let saving = false;
document.getElementById("save-form").addEventListener("submit", function () {
  saving = true;
});
window.addEventListener("beforeunload", function (event) {
  if (!saving && Object.keys(changes).length > 0) {
    event.preventDefault();
    event.returnValue = "";
  }
});
