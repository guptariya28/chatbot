# Atlassian OAuth 2.0 (3LO) login: /login, /callback, /logout
import os, secrets
import requests
from urllib.parse import urlencode
from dotenv import load_dotenv
from flask import Blueprint, redirect, request, session

load_dotenv()

CLIENT_ID = os.environ["ATLASSIAN_CLIENT_ID"]
CLIENT_SECRET = os.environ["ATLASSIAN_CLIENT_SECRET"]
CALLBACK = "http://localhost:5000/callback"

auth = Blueprint("auth", __name__)


@auth.route("/login")
def login():
    session["state"] = secrets.token_urlsafe(16)  # random value to check on the way back
    params = {
        "audience": "api.atlassian.com",
        "client_id": CLIENT_ID,
        "scope": "read:jira-work offline_access",
        "redirect_uri": CALLBACK,
        "state": session["state"],
        "response_type": "code",
        "prompt": "consent",
    }
    return redirect("https://auth.atlassian.com/authorize?" + urlencode(params))


@auth.route("/callback")
def callback():
    if request.args.get("state") != session.pop("state", None):
        return "Login check failed. <a href='/login'>Try again</a>", 400

    r = requests.post("https://auth.atlassian.com/oauth/token", json={
        "grant_type": "authorization_code",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "code": request.args.get("code"),
        "redirect_uri": CALLBACK,
    })
    r.raise_for_status()
    session["token"] = r.json()["access_token"]
    return redirect("/")


@auth.route("/logout")
def logout():
    session.clear()
    return "Logged out. <a href='/login'>Log in again</a>"
