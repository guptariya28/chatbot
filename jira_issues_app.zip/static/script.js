// ROWS, COLUMNS and SITE come from index.html (sent by Flask)

// ---------- What the user has chosen ----------
const columns = COLUMNS;
const hidden = new Set();   // columns turned off in the "Columns" menu
const filters = {};         // column -> Set of values to keep
let search = "";
let sortCol = null;
let sortAsc = true;

const FUNNEL = '<svg width="12" height="12" viewBox="0 0 16 16"><path d="M1 2h14l-5.5 6.5V14l-3-1.5V8.5z" fill="currentColor"/></svg>';
const colMenu = document.getElementById("colMenu");
const filterMenu = document.getElementById("filterMenu");


// Make text safe to put inside HTML
function esc(text) {
  return String(text).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// How one cell looks
function cell(col, value) {
  if (col === "Key") return `<a href="${SITE}/browse/${esc(value)}" target="_blank">${esc(value)}</a>`;
  if (col === "Status" || col === "Priority") {
    return `<span class="badge ${col.toLowerCase()}-${esc(value).toLowerCase().replace(/[^a-z]/g, "")}">${esc(value)}</span>`;
  }
  return esc(value);
}

// Rows that pass the search, the filters and the sort
function visibleRows() {
  const rows = ROWS.filter(row =>
    Object.keys(filters).every(col => filters[col].has(row[col])) &&
    Object.values(row).join(" ").toLowerCase().includes(search)
  );
  if (sortCol) {
    rows.sort((a, b) => String(a[sortCol]).localeCompare(String(b[sortCol]), undefined, { numeric: true }) * (sortAsc ? 1 : -1));
  }
  return rows;
}


// ---------- Draw the table ----------
function render() {
  const cols = columns.filter(c => !hidden.has(c));
  const rows = visibleRows();

  document.querySelector("#issues thead").innerHTML =
    "<tr><th class='num'>#</th>" +
    cols.map(c => `
      <th>
        <div class="th">
          <span class="sort" data-col="${c}">${c} ${sortCol === c ? (sortAsc ? "▲" : "▼") : ""}</span>
          <button class="funnel ${filters[c] ? "active" : ""}" data-col="${c}" title="Filter ${c}">${FUNNEL}</button>
        </div>
      </th>`).join("") +
    "</tr>";

  document.querySelector("#issues tbody").innerHTML = rows.map((row, i) =>
    `<tr><td class="num">${i + 1}</td>` + cols.map(c => `<td class="col-${c.replace(/\W/g, "")}">${cell(c, row[c])}</td>`).join("") + "</tr>"
  ).join("") || `<tr><td colspan="${cols.length + 1}" class="empty">No issues match. Try clearing the filters.</td></tr>`;

  document.getElementById("shown").textContent = rows.length;
  document.getElementById("total").textContent = ROWS.length;
  document.getElementById("colCount").textContent = `${cols.length} / ${columns.length}`;
}


// ---------- Dropdown menus ----------
function openMenu(menu, button) {
  const box = button.getBoundingClientRect();
  menu.style.top = box.bottom + 6 + "px";
  menu.style.left = Math.min(box.left, window.innerWidth - 280) + "px";
  menu.classList.remove("hidden");
}

// Filter dropdown for one column: a checkbox for every value
function openFilter(col, button) {
  const values = [...new Set(ROWS.map(r => r[col]))].sort();
  filterMenu.dataset.col = col;
  filterMenu.innerHTML = `
    <input class="menu-search" placeholder="Search ${col}...">
    <div class="menu-actions">
      <button data-act="all">Select all</button>
      <button data-act="none">Clear</button>
    </div>
    <div class="menu-list">` +
    values.map(v => `
      <label><input type="checkbox" value="${esc(v)}" ${!filters[col] || filters[col].has(v) ? "checked" : ""}>
      ${esc(v) || "<i>(empty)</i>"}</label>`).join("") +
    "</div>";
  openMenu(filterMenu, button);
}

// Read the ticked boxes and save them as the filter for that column
function applyFilter() {
  const col = filterMenu.dataset.col;
  const boxes = [...filterMenu.querySelectorAll(".menu-list input")];
  const ticked = boxes.filter(b => b.checked).map(b => b.value);
  if (ticked.length === boxes.length) delete filters[col];  // everything ticked = no filter
  else filters[col] = new Set(ticked);
  render();
}

// Columns dropdown: a checkbox for every column
function openColumns(button) {
  colMenu.innerHTML = "<div class='menu-list'>" + columns.map(c =>
    `<label><input type="checkbox" value="${c}" ${hidden.has(c) ? "" : "checked"}> ${c}</label>`).join("") + "</div>";
  openMenu(colMenu, button);
}


// ---------- Clicks and typing ----------
document.getElementById("search").addEventListener("input", e => {
  search = e.target.value.toLowerCase();
  render();
});

document.getElementById("clearBtn").addEventListener("click", () => {
  Object.keys(filters).forEach(col => delete filters[col]);
  render();
});

document.getElementById("colBtn").addEventListener("click", e => openColumns(e.currentTarget));

colMenu.addEventListener("change", e => {
  e.target.checked ? hidden.delete(e.target.value) : hidden.add(e.target.value);
  render();
});

document.querySelector("#issues thead").addEventListener("click", e => {
  const funnel = e.target.closest(".funnel");
  const sort = e.target.closest(".sort");
  if (funnel) openFilter(funnel.dataset.col, funnel);
  if (sort) {
    sortAsc = sortCol === sort.dataset.col ? !sortAsc : true;
    sortCol = sort.dataset.col;
    render();
  }
});

filterMenu.addEventListener("change", applyFilter);

filterMenu.addEventListener("click", e => {
  const act = e.target.dataset.act;
  if (!act) return;
  filterMenu.querySelectorAll(".menu-list input").forEach(b => b.checked = act === "all");
  applyFilter();
});

filterMenu.addEventListener("input", e => {  // search inside the filter list
  if (!e.target.classList.contains("menu-search")) return;
  const text = e.target.value.toLowerCase();
  filterMenu.querySelectorAll(".menu-list label").forEach(l => {
    l.style.display = l.textContent.toLowerCase().includes(text) ? "" : "none";
  });
});

// Click anywhere else = close the menus
document.addEventListener("click", e => {
  if (!e.target.closest(".menu, .funnel, #colBtn")) {
    colMenu.classList.add("hidden");
    filterMenu.classList.add("hidden");
  }
});

render();
