# excel_writer.py
# Writes the changes made on the portal into portal_data.xlsx (the main data file).
#
# portal_data.xlsx is now the ONE place where the data lives:
#   - the portal reads it      (excel_reader.py)
#   - the portal writes to it  (this file), every time you click "Save changes",
#     raise a Non-AOP request, or approve / reject one.
#
# Only the rows that changed are written. Everything else in the file stays as it is.

from datetime import datetime
from openpyxl import load_workbook

from excel_reader import EXCEL_FILE, SHEET_NAME, find_header_row


# A value from the portal -> a value for an Excel cell
#   ""            -> empty cell
#   numpy numbers -> normal Python numbers
def excel_value(value):
    if value is None or value == "":
        return None
    if hasattr(value, "item") and not isinstance(value, datetime):   # numpy number, e.g. numpy.int64
        return value.item()
    return value


# Writes some rows into the main sheet of portal_data.xlsx.
#   rows    : the rows to write (dicts, as in the portal)
#   columns : the Excel columns in order (ALL_COLUMNS): columns[0] is Excel column A, columns[1] is B ...
# A new row (a new Non-AOP request) has no Excel row yet: it is added at the bottom.
# Returns "" when it worked, or a message saying what went wrong.
def write_rows(rows, columns):
    try:
        workbook = load_workbook(EXCEL_FILE)
    except PermissionError:
        return "portal_data.xlsx is open in Excel. Close it, then click Retry."

    sheet = workbook[SHEET_NAME]
    header_excel_row = find_header_row() + 1   # pandas counts from 0, Excel from 1

    for row in rows:
        # 1. Which Excel row? New rows go under the last row.
        excel_row = row.get("excel_row", "")
        if excel_row == "" or excel_row is None:
            excel_row = sheet.max_row + 1
            row["excel_row"] = excel_row

        # 2. The normal columns: same position as in the Excel
        for position in range(len(columns)):
            value = row.get(columns[position], "")
            sheet.cell(row=excel_row, column=position + 1, value=excel_value(value))

        # 3. Columns the portal added itself (e.g. "Request Status" of a Non-AOP request).
        #    Found by name in the header row; if the column is not there yet, it is added at the end.
        for name in row:
            if name in columns or name == "id" or name == "excel_row":
                continue
            column_number = find_or_add_column(sheet, header_excel_row, name)
            sheet.cell(row=excel_row, column=column_number, value=excel_value(row[name]))

    try:
        workbook.save(EXCEL_FILE)
    except PermissionError:
        return "portal_data.xlsx is open in Excel. Close it, then click Retry."
    return ""


# The Excel column number of a column name in the header row (adds the column at the end if it is missing)
def find_or_add_column(sheet, header_excel_row, name):
    for cell in sheet[header_excel_row]:
        if cell.value is not None and str(cell.value).strip() == name:
            return cell.column
    new_number = sheet.max_column + 1
    sheet.cell(row=header_excel_row, column=new_number, value=name)
    return new_number
