# extract_excel.py
# ONE-TIME SETUP: makes portal_data.xlsx from the big Excel.
#
#   Big file  : MBBP26_Apr_V1.xlsx   (all sheets, pivots ... slow to read)
#   Small file: portal_data.xlsx     (only the main sheet + the 6 master sheets, values only)
#
# After this, portal_data.xlsx is the MAIN data file:
#   - the portal reads it and writes every "Save changes" into it
#   - change masters or data by hand in portal_data.xlsx (not in the big Excel)
#
# Run it once:   python extract_excel.py
# It will NOT overwrite an existing portal_data.xlsx (that would delete the changes made on the portal).
# To really start again from the big Excel: delete (or rename) portal_data.xlsx first, then run it.
#
# This file never changes the big Excel. It only reads it.

import os
import warnings
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter

warnings.filterwarnings("ignore")      # hide the harmless "Data Validation" warning

HERE = os.path.dirname(os.path.abspath(__file__))       # the portal folder
BIG_FILE = os.path.join(HERE, "MBBP26_Apr_V1.xlsx")
SMALL_FILE = os.path.join(HERE, "portal_data.xlsx")

MAIN_SHEET = "MBBP_2026_09Apr"

# The master sheets (tab names in the big Excel). Same list as MASTER_SHEETS in excel_reader.py
MASTER_SHEET_NAMES = ["IO Leads", "Reporter", "Customer l4", "Module", "Stakeholders_list", "business group"]


# Finds a sheet by name. Small/capital letters and extra spaces don't matter ("Customer L4" = "customer l4 ")
def find_sheet(workbook, wanted):
    for name in workbook.sheetnames:
        if name.strip().lower() == wanted.strip().lower():
            return workbook[name]
    return None


# Copies every cell VALUE of one sheet into the new file (formulas -> their result)
def copy_sheet(old_sheet, new_file, keep_hidden_columns):
    new_sheet = new_file.create_sheet(old_sheet.title)
    for row in old_sheet.iter_rows(values_only=True):
        new_sheet.append(row)

    # The portal shows the same columns the Excel shows, so we copy which columns are hidden
    if keep_hidden_columns:
        for dimension in old_sheet.column_dimensions.values():
            if dimension.hidden and dimension.min:
                for number in range(dimension.min, dimension.max + 1):
                    new_sheet.column_dimensions[get_column_letter(number)].hidden = True
    return new_sheet


def extract():
    # Never overwrite the main data file
    if os.path.exists(SMALL_FILE):
        print("portal_data.xlsx already exists - it is the main data file now, so it was NOT overwritten.")
        print("To start again from", os.path.basename(BIG_FILE) + ": delete or rename portal_data.xlsx, then run this again.")
        return

    print("Reading", os.path.basename(BIG_FILE), "(this can take a minute) ...")
    # data_only=True -> we get the numbers the formulas show, not the formulas
    big = load_workbook(BIG_FILE, data_only=True)

    small = Workbook()
    small.remove(small.active)          # a new file starts with an empty "Sheet" - remove it

    # 1. The main sheet
    main = find_sheet(big, MAIN_SHEET)
    if main is None:
        print("ERROR: sheet", MAIN_SHEET, "not found. Nothing saved.")
        return
    copy_sheet(main, small, True)
    print("  copied", main.title, "-", main.max_row, "rows")

    # 2. The master sheets
    for name in MASTER_SHEET_NAMES:
        sheet = find_sheet(big, name)
        if sheet is None:
            print("  WARNING: master sheet", name, "not found - that column keeps its old dropdown")
            continue
        copy_sheet(sheet, small, False)
        print("  copied", sheet.title, "-", sheet.max_row - 1, "names")

    small.save(SMALL_FILE)
    print("Saved", os.path.basename(SMALL_FILE))


if __name__ == "__main__":
    extract()
