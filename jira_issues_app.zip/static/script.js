// ROWS, COLUMNS and SITE come from index.html (sent by Flask)

const ROW_H = 36;          // every row has the same height, so we can work out which rows are on screen
const BUFFER = 10;         // draw a few extra rows above and below the screen
const MAX_LIST = 300;      // longest list shown in a filter panel
const NUM_W = 50;          // width of the "#" column
const COUNT_COLUMN = "attachment count";

const wrap = document.getElementById("wrap");
const table = document.getElementById("issues");
const colMenu = document.getElementById("colMenu");
const filterMenu = document.getElementById("filterMenu");
const cellMenu = document.getElementById("cellMenu");

const ICON_FILTER = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 4h12M4.5 8h7M7 12h2"/></svg>';
const ICON_CHEV = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6l4 4 4-4"/></svg>';

// ---------- What the user has chosen ----------
const hidden = new Set();   // columns turned off in the "Columns" menu
const filters = {};         // column -> Set of values to keep
let search = "";
let sortCol = null;
let sortAsc = true;
let view = [];              // the rows that pass search + filters, in sorted order
let stamp = 0;              // changes whenever the view changes, so we know to redraw
let lastKey = "";
let tbody = null;


// ---------- Prepare the data once ----------
const HAY = [];             // one lowercase text per row, used by the search box
const uniques = {};         // column -> sorted list of its different values
const widths = {};          // column -> width in pixels
const isCategory = {};      // column -> true when it has only a few different values (gets the dropdown icon)

for (const row of ROWS) {
  for (const col of COLUMNS) row[col] = String(row[col]);
  HAY.push(Object.values(row).join(" ").toLowerCase());
}

for (const col of COLUMNS) {
  const set = new Set();
  // the header may wrap onto 2-3 lines, but its longest word must still fit
  let longest = Math.max(Math.ceil(col.length / 2.4), ...col.split(".").map(word => word.length + 1));
  for (const row of ROWS) {
    set.add(row[col]);
    longest = Math.max(longest, Math.min(row[col].length, 60));
  }
  uniques[col] = [...set].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  isCategory[col] = set.size <= 30 && col !== "key" && col !== COUNT_COLUMN;
  widths[col] = Math.min(Math.max(longest * 7.4 + 36 + (isCategory[col] ? 22 : 0), 96), 360);
}


// ---------- Small helpers ----------
function esc(text) {
  return String(text).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function visibleCols() {
  return COLUMNS.filter(c => !hidden.has(c));
}

// One cell
function cell(col, value, rowIndex) {
  const shown = value.replace(/\n/g, ", ");
  let inner;
  if (col === "key") inner = `<a href="${SITE}/browse/${esc(value)}" target="_blank">${esc(value)}</a>`;
  else if (value === "" || (col === COUNT_COLUMN && value === "0")) inner = '<span class="dash">—</span>';
  else if (col === COUNT_COLUMN) inner = `<span class="att">📎 ${esc(value)}</span>`;
  else if (col === "fields.status.name" || col === "fields.priority.name") {
    inner = `<span class="badge ${col.split(".")[1]}-${esc(value).toLowerCase().replace(/[^a-z]/g, "")}">${esc(value)}</span>`;
  }
  else if (value.startsWith("http")) inner = `<a href="${esc(value)}" target="_blank">open</a>`;
  else inner = `<span class="t">${esc(shown)}</span>`;

  const icon = isCategory[col] ? `<button class="dd" data-col="${esc(col)}" data-row="${rowIndex}">${ICON_CHEV}</button>` : "";
  return `<td class="${col === "key" ? "stick" : ""}" title="${esc(shown)}"><div class="c">${inner}${icon}</div></td>`;
}


// ---------- Work out which rows to show ----------
function updateView() {
  const out = [];
  for (let i = 0; i < ROWS.length; i++) {
    if (search && !HAY[i].includes(search)) continue;
    let keep = true;
    for (const col in filters) {
      if (!filters[col].has(ROWS[i][col])) { keep = false; break; }
    }
    if (keep) out.push(ROWS[i]);
  }
  if (sortCol) {
    out.sort((a, b) => a[sortCol].localeCompare(b[sortCol], undefined, { numeric: true }) * (sortAsc ? 1 : -1));
  }
  view = out;
  stamp++;

  document.getElementById("shown").textContent = view.length;
  document.getElementById("total").textContent = ROWS.length;
  document.getElementById("colCount").textContent = `${visibleCols().length} / ${COLUMNS.length}`;

  drawHeader();
  wrap.scrollTop = 0;
  drawBody();
}


// ---------- Draw the table ----------
function drawHeader() {
  let colgroup = `<col style="width:${NUM_W}px">`;
  let head = '<tr><th class="num">#</th>';
  let total = NUM_W;

  for (const col of visibleCols()) {
    total += widths[col];
    colgroup += `<col style="width:${widths[col]}px">`;
    const arrow = sortCol === col ? (sortAsc ? " ▲" : " ▼") : "";
    head += `<th class="${col === "key" ? "stick" : ""}"><div class="th">
      <span class="name" title="${esc(col)}">${esc(col).replace(/\./g, ".<wbr>")}${arrow}</span>
      <button class="fi ${filters[col] ? "on" : ""}" data-col="${esc(col)}" title="Filter">${ICON_FILTER}</button>
    </div></th>`;
  }

  table.style.width = total + "px";
  table.innerHTML = `<colgroup>${colgroup}</colgroup><thead>${head}</tr></thead><tbody></tbody>`;
  tbody = table.querySelector("tbody");
  lastKey = "";
}

// Draw only the rows that are on screen (plus a few extra). Spacer rows keep the scrollbar the right size.
function drawBody() {
  const first = Math.max(0, Math.floor(wrap.scrollTop / ROW_H) - BUFFER);
  const last = Math.min(view.length, Math.ceil((wrap.scrollTop + wrap.clientHeight) / ROW_H) + BUFFER);
  const key = first + ":" + last + ":" + stamp;
  if (key === lastKey) return;       // nothing new to draw
  lastKey = key;

  const cols = visibleCols();
  if (view.length === 0) {
    const msg = ROWS.length === 0 ? "Jira returned 0 issues. Check the terminal where app.py is running." : "No issues match. Try clearing the filters.";
    tbody.innerHTML = `<tr><td colspan="${cols.length + 1}" class="empty"><div class="emptymsg">${msg}</div></td></tr>`;
    return;
  }

  let html = first > 0 ? `<tr class="pad"><td colspan="${cols.length + 1}" style="height:${first * ROW_H}px"></td></tr>` : "";
  for (let i = first; i < last; i++) {
    html += `<tr class="${i % 2 ? "alt" : ""}"><td class="num">${i + 1}</td>`;
    for (const col of cols) html += cell(col, view[i][col], i);
    html += "</tr>";
  }
  if (last < view.length) html += `<tr class="pad"><td colspan="${cols.length + 1}" style="height:${(view.length - last) * ROW_H}px"></td></tr>`;
  tbody.innerHTML = html;
}

// Scrolling: draw again, at most once per screen refresh
let waiting = false;
wrap.addEventListener("scroll", () => {
  closeMenus();
  if (waiting) return;
  waiting = true;
  requestAnimationFrame(() => { waiting = false; drawBody(); });
}, { passive: true });
window.addEventListener("resize", drawBody);


// ---------- Dropdown menus ----------
function closeMenus() {
  for (const menu of [colMenu, filterMenu, cellMenu]) {
    if (!menu.classList.contains("hidden")) menu.classList.add("hidden");
  }
}

// Show a menu under an element, kept inside the window
function placeMenu(menu, anchor) {
  closeMenus();
  const box = anchor.getBoundingClientRect();
  menu.classList.remove("hidden");
  const left = Math.min(box.left, window.innerWidth - menu.offsetWidth - 12);
  let top = box.bottom + 4;
  if (top + menu.offsetHeight > window.innerHeight - 8) top = Math.max(8, window.innerHeight - menu.offsetHeight - 8);
  menu.style.left = Math.max(8, left) + "px";
  menu.style.top = top + "px";
}

// Column filter panel: sort, search and a checkbox for every value
const panel = { col: "", selected: new Set(), matches: [] };

function openFilter(col, button) {
  panel.col = col;
  panel.selected = new Set(filters[col] || uniques[col]);
  filterMenu.innerHTML = `
    <div class="mi" data-sort="asc"><span>▲ Sort A to Z</span></div>
    <div class="mi" data-sort="desc"><span>▼ Sort Z to A</span></div>
    <div class="mi muted" data-sort="none">Clear sort</div>
    <input class="msearch" placeholder="Search">
    <div class="mlist"></div>
    <div class="mfoot">
      <button data-act="clear">Clear filter</button>
      <button data-act="cancel">Cancel</button>
      <button data-act="ok" class="ok">OK</button>
    </div>`;
  drawList("");
  placeMenu(filterMenu, button.closest("th"));
  filterMenu.querySelector(".msearch").focus();
}

// The checkbox list inside the filter panel
function drawList(query) {
  const q = query.toLowerCase();
  panel.matches = uniques[panel.col].filter(v => v.toLowerCase().includes(q));
  const all = panel.matches.length > 0 && panel.matches.every(v => panel.selected.has(v));

  let html = `<label><input type="checkbox" data-all ${all ? "checked" : ""}> (Select All)</label>`;
  const shown = Math.min(panel.matches.length, MAX_LIST);
  for (let i = 0; i < shown; i++) {
    const v = panel.matches[i];
    html += `<label><input type="checkbox" data-i="${i}" ${panel.selected.has(v) ? "checked" : ""}> <span>${v === "" ? "(Blank)" : esc(v.replace(/\n/g, ", "))}</span></label>`;
  }
  if (panel.matches.length > MAX_LIST) html += `<div class="more">${panel.matches.length - MAX_LIST} more... type in Search to find them</div>`;
  filterMenu.querySelector(".mlist").innerHTML = html;
}

// Cell dropdown: the values of that column, the current one ticked
function openCellMenu(col, rowIndex, button) {
  const current = view[rowIndex][col];
  cellMenu.dataset.col = col;
  let html = "";
  if (uniques[col].includes("")) html += '<div class="mi muted" data-i="-1"><i>— Blank —</i></div><div class="sep"></div>';
  uniques[col].forEach((v, i) => {
    if (v === "") return;
    html += `<div class="mi ${v === current ? "cur" : ""}" data-i="${i}"><span>${esc(v)}</span>${v === current ? "<span>✓</span>" : ""}</div>`;
  });
  cellMenu.innerHTML = `<div class="mlist">${html}</div>`;
  placeMenu(cellMenu, button.closest("td"));
}

// Columns menu
function openColumns(button) {
  colMenu.innerHTML = '<div class="mlist">' + COLUMNS.map(c =>
    `<label><input type="checkbox" value="${esc(c)}" ${hidden.has(c) ? "" : "checked"}> ${esc(c)}</label>`).join("") + "</div>";
  placeMenu(colMenu, button);
}


// ---------- Clicks and typing ----------
document.getElementById("search").addEventListener("input", e => {
  search = e.target.value.toLowerCase();
  updateView();
});

document.getElementById("clearBtn").addEventListener("click", () => {
  for (const col in filters) delete filters[col];
  sortCol = null;
  updateView();
});

document.getElementById("colBtn").addEventListener("click", e => openColumns(e.currentTarget));

colMenu.addEventListener("change", e => {
  e.target.checked ? hidden.delete(e.target.value) : hidden.add(e.target.value);
  updateView();
});

// Filter icon in a header, or dropdown icon in a cell
table.addEventListener("click", e => {
  const fi = e.target.closest(".fi");
  const dd = e.target.closest(".dd");
  if (fi) openFilter(fi.dataset.col, fi);
  if (dd) openCellMenu(dd.dataset.col, Number(dd.dataset.row), dd);
});

filterMenu.addEventListener("input", e => {
  if (e.target.classList.contains("msearch")) drawList(e.target.value);
});

filterMenu.addEventListener("change", e => {
  const list = filterMenu.querySelector(".mlist");
  if ("all" in e.target.dataset) {            // (Select All) for the values that match the search
    for (const v of panel.matches) e.target.checked ? panel.selected.add(v) : panel.selected.delete(v);
    list.querySelectorAll("input[data-i]").forEach(b => b.checked = e.target.checked);
  } else {                                     // one value
    const v = panel.matches[Number(e.target.dataset.i)];
    e.target.checked ? panel.selected.add(v) : panel.selected.delete(v);
    list.querySelector("input[data-all]").checked = panel.matches.every(x => panel.selected.has(x));
  }
});

filterMenu.addEventListener("click", e => {
  const sort = e.target.closest("[data-sort]");
  const act = e.target.dataset.act;
  if (sort) {
    sortCol = sort.dataset.sort === "none" ? null : panel.col;
    sortAsc = sort.dataset.sort === "asc";
    closeMenus();
    updateView();
  }
  if (act === "cancel") closeMenus();
  if (act === "clear") { delete filters[panel.col]; closeMenus(); updateView(); }
  if (act === "ok") {
    if (panel.selected.size === uniques[panel.col].length) delete filters[panel.col];   // everything ticked = no filter
    else filters[panel.col] = new Set(panel.selected);
    closeMenus();
    updateView();
  }
});

// Picking a value in a cell dropdown shows only the rows with that value (the Jira data itself is not changed)
cellMenu.addEventListener("click", e => {
  const item = e.target.closest("[data-i]");
  if (!item) return;
  const col = cellMenu.dataset.col;
  const i = Number(item.dataset.i);
  filters[col] = new Set([i < 0 ? "" : uniques[col][i]]);
  closeMenus();
  updateView();
});

// Click anywhere else, or press Escape = close the menus
document.addEventListener("click", e => {
  if (!e.target.closest(".menu, .fi, .dd, #colBtn")) closeMenus();
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape") closeMenus();
});

updateView();
