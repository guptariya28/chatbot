// ============================================================
// app.js - the whole portal works without reloading the page
//
//   1. Tabs       -> click a tab, it is shown. The browser remembers it (F5 opens the same tab).
//   2. Forms      -> Save, Approve, New request, Settings, "Viewing as", Retry:
//                    sent to Python with fetch(). Python answers with a message (JSON).
//   3. Overview   -> filters, chart clicks, Month / Quarter: loaded with fetch(), no reload.
//   4. Redraw     -> after every action we ask Python for the page "/" again and
//                    swap in the new tabs. The address always stays "/".
// ============================================================


// The Overview filters chosen now, e.g. "io_lead=Ravi+S&period=quarter" ("" = no filter)
let overviewFilters = "";


// ---------- 1. Tabs ----------

// Shows the tab that pickTab() gives (pickTab is at the top of index.html)
function showTab() {
  const tab = pickTab();
  document.documentElement.setAttribute("data-tab", tab);

  // Light up the tab in the top bar ("New request" belongs to Non-AOP)
  const lit = (tab === "new-request") ? "requests" : tab;
  for (const link of document.querySelectorAll(".tabs a")) {
    link.classList.toggle("active", link.dataset.tab === lit);
  }
}

// Opens a tab and remembers it, so F5 opens the same tab
function openTab(tab) {
  try {
    sessionStorage.setItem("tab", tab);
  } catch (error) {}
  showTab();
  window.scrollTo(0, 0);
}


// ---------- 2. A short message at the bottom ("Saved 2 change(s)") ----------

let toastTimer = null;
function showMessage(text) {
  if (!text) {
    return;
  }
  const toast = document.getElementById("toast");
  toast.textContent = text;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { toast.hidden = true; }, 2500);
}


// ---------- 3. Draw the page again (no reload) ----------

// Asks Python for "/" again and swaps in the new top bar and tabs.
// withRegister = true -> the Demand register is drawn again too (new rows, saved values ...).
// It is left alone when false, so a half-edited table is never lost.
async function refreshPage(withRegister) {
  const answer = await fetch("/?" + overviewFilters);
  const html = await answer.text();
  const newPage = new DOMParser().parseFromString(html, "text/html");

  const parts = [".top-bar", "#excel-problem-box", "#tab-overview", "#tab-summary",
                 "#tab-requests", "#tab-new-request", "#tab-log"];
  if (withRegister) {
    parts.push("#tab-register");
  }

  // Keep the table where you scrolled it
  const box = document.querySelector(".sheet-box");
  const scrollTop = box ? box.scrollTop : 0;
  const scrollLeft = box ? box.scrollLeft : 0;

  for (const part of parts) {
    const oldPart = document.querySelector(part);
    const newPart = newPage.querySelector(part);
    if (oldPart && newPart) {
      oldPart.replaceWith(newPart);
    }
  }

  if (withRegister) {
    startRegister();                    // in register.js: connects the new table again
    const newBox = document.querySelector(".sheet-box");
    newBox.scrollTop = scrollTop;
    newBox.scrollLeft = scrollLeft;
  }
  showTab();
}


// ---------- 4. Forms: sent with fetch() instead of reloading ----------

document.addEventListener("submit", async function (event) {
  const form = event.target;
  event.preventDefault();               // stop the normal page reload

  // The Overview filter bar (method="get"): load the Overview with these filters
  if (form.method.toLowerCase() === "get") {
    const filters = new URLSearchParams(new FormData(form));
    // leave out empty filters, so the address Python sees stays short
    for (const [name, value] of Array.from(filters.entries())) {
      if (value === "") {
        filters.delete(name);
      }
    }
    overviewFilters = filters.toString();
    await refreshPage(false);
    return;
  }

  // Every other form (method="post"): send it, then show the answer and draw the page again
  const answer = await fetch(form.action, { method: "POST", body: new FormData(form) });
  let result = {};
  try {
    result = await answer.json();
  } catch (error) {
    result = { message: "Something went wrong - please try again" };
  }

  if (result.register) {
    changes = {};                       // in register.js: the saved changes are not "unsaved" any more
  }
  if (result.tab) {
    openTab(result.tab);
  }
  await refreshPage(result.register === true);
  showMessage(result.message);
});


// ---------- 5. Links: tabs and Overview filters, without changing the address ----------

document.addEventListener("click", async function (event) {
  const link = event.target.closest("a");
  if (!link) {
    return;
  }
  const href = link.getAttribute("href") || "";

  // "#register", "#new-request" ... -> open that tab
  if (href.startsWith("#") && TABS.indexOf(href.slice(1)) >= 0) {
    event.preventDefault();
    openTab(href.slice(1));
    return;
  }

  // "/?tech_module=FICO", "?" (Clear filters), Month / Quarter -> filter the Overview
  if (href.startsWith("?") || href.startsWith("/?")) {
    event.preventDefault();
    overviewFilters = href.split("?")[1];
    openTab("overview");
    await refreshPage(false);
  }
});


// ---------- 6. Chart cards: switch between Chart and Table ----------

function showView(cardId, view) {
  document.getElementById(cardId + "-chart").hidden = (view !== "chart");
  document.getElementById(cardId + "-table").hidden = (view !== "table");
  document.getElementById(cardId + "-chart-button").classList.toggle("active", view === "chart");
  document.getElementById(cardId + "-table-button").classList.toggle("active", view === "table");
}


// ---------- Start ----------

// An old address like /#register or /?io_lead=Mani: use it once, then show just "/"
if (TABS.indexOf(location.hash.slice(1)) >= 0) {
  openTab(location.hash.slice(1));
}
if (location.search !== "") {
  overviewFilters = location.search.slice(1);
}
history.replaceState(null, "", "/");
showTab();
