import truststore
truststore.inject_into_ssl()  # use the Windows certificate store (corporate CA)

import os, io, time, requests
import pandas as pd
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, send_file

load_dotenv()

SITE = "https://mercedes-benz-pace.atlassian.net"
AUTH = (os.environ["ATLASSIAN_EMAIL"], os.environ["ATLASSIAN_API_TOKEN"])

PROJECTS = ["FPM", "SAC", "TAFM"]
JQL = f"project in ({', '.join(PROJECTS)}) ORDER BY created DESC"
CACHE_MINUTES = 10  # reuse the data for 10 minutes instead of asking Jira on every page load

# The table columns: paths in the Jira JSON, exactly as the REST API names them.
# The path is also the column name. To add a column, just add a path here.
# If a path goes through an array (like attachment), every item is read and joined with ", ".
COLUMNS = [
    "key",
    "fields.summary",
    "fields.issuetype.name",
    "fields.project.key",
    "fields.project.projectTypeKey",
    "fields.status.name",
    "fields.status.statusCategory.key",
    "fields.status.statusCategory.name",
    "fields.status.statusCategory.colorName",
    "fields.priority.name",
    "fields.resolution.name",
    "fields.resolutiondate",
    "fields.reporter.displayName",
    "fields.reporter.emailAddress",
    "fields.assignee.displayName",
    "fields.created",
    "fields.updated",
    "fields.duedate",
    "fields.attachment.self",
    "fields.attachment.filename",
    "fields.attachment.author.emailAddress",
    "fields.attachment.created",
    "fields.attachment.content",
]

# Ask Jira only for the fields used above, e.g. "summary,issuetype,project,..."
field_names = []
for path in COLUMNS:
    if path.startswith("fields."):
        name = path.split(".")[1]          # "fields.status.name" -> "status"
        if name not in field_names:
            field_names.append(name)
FIELDS = ",".join(field_names)

# If Jira is slow or a request fails, try again up to 3 times
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=Retry(total=3, backoff_factor=2)))

app = Flask(__name__)
cache = {"rows": [], "time": 0}


def get_value(issue, path):
    # Follow the path one key at a time, e.g. "fields.attachment.filename".
    # We keep a list because an array (like attachment) can give many values.
    values = [issue]
    for key in path.split("."):
        next_values = []
        for value in values:
            if not isinstance(value, dict):
                continue
            item = value.get(key)              # missing key or null -> None, no error
            if isinstance(item, list):
                next_values.extend(item)       # array: keep every item
            elif item is not None:
                next_values.append(item)
        values = next_values

    # Turn the values into one text, e.g. "file1.pdf, file2.pdf"
    texts = []
    for value in values:
        text = str(value)
        if len(text) > 10 and text[4] == "-" and text[10] == "T":  # "2026-11-13T09:15:44..." -> "2026-11-13"
            text = text[:10]
        texts.append(text)
    return ", ".join(texts)


def get_rows():
    # Use the saved data if it is still fresh
    if cache["rows"] and time.time() - cache["time"] < CACHE_MINUTES * 60:
        return cache["rows"]

    url = f"{SITE}/rest/api/3/search/jql"
    params = {"jql": JQL, "fields": FIELDS, "maxResults": 100}

    # 1. Get all issues, page by page, keeping only the columns above
    rows = []
    while True:
        r = session.get(url, headers={"Accept": "application/json"}, auth=AUTH, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()

        for issue in data["issues"]:
            row = {}
            for path in COLUMNS:
                row[path] = get_value(issue, path)
            rows.append(row)

        if data.get("isLast", True):
            break
        params["nextPageToken"] = data["nextPageToken"]

    # 2. Save for next time
    cache["rows"], cache["time"] = rows, time.time()
    return rows


@app.route("/")
def index():
    if request.args.get("refresh"):  # "Refresh" button: forget the saved data
        cache["time"] = 0
        return redirect("/")
    return render_template("index.html", rows=get_rows(), columns=COLUMNS, site=SITE, projects=PROJECTS)


@app.route("/export")
def export():
    file = io.BytesIO()
    pd.DataFrame(get_rows()).to_excel(file, index=False)
    file.seek(0)
    return send_file(file, download_name="jira_issues.xlsx", as_attachment=True)


if __name__ == "__main__":
    app.run(port=5000, debug=True)
