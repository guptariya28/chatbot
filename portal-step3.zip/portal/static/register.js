// ============================================================
// register.js - makes the Demand register work like Excel
//
//   1. Filter icon in a header -> filter menu (sort, search, tick values)
//   2. Click a cell            -> type in the cell, a list of matching values opens under it
//   3. Save bar                -> sends the changed cells to Python (/register/save)
//   4. Columns button          -> tick the columns you want to see
//
// Python still does the saving, the permissions and the change log.
// This file only changes what you see in the browser.
// ============================================================


// ---------- What we remember while the page is open ----------

let columnFilters = {};   // column number -> list of ticked values,  e.g. { "2": ["fg", "controlling"] }
let filterLabels = {};    // column number -> the same values as shown,  e.g. { "2": ["FG", "Controlling"] }
let menuLabels = {};      // value -> label, for the menu that is open now
let changes = {};         // "id_column" -> { id, col, row, oldValue, newValue }
let openColumn = null;    // the column whose filter menu is open
let searchText = "";      // text in the "Search" box
let shownColumns = [];    // column numbers that are shown (the rest is hidden)

// The cell being edited
let editCell = null;      // the <td>
let editInput = null;     // the text box inside it
let editTyped = false;    // false = nothing typed yet, so the list shows every value
let editChoices = [];     // the values in the list now:  [{ value, isNew }]
let editPick = 0;         // which line of the list is highlighted


// ---------- Small helpers ----------

// All table rows (the <tr> elements in the body)
function getRows() {
  return Array.from(document.querySelectorAll("#sheet tbody tr"));
}

// One cell of a row, found by its column number
function getCell(row, col) {
  return row.querySelector('td[data-col="' + col + '"]');
}

// The value we filter on: small letters, and "(blanks)" for an empty cell
function filterValue(cell) {
  const value = cell.dataset.value.trim();
  if (value === "") {
    return "(blanks)";
  }
  return value.toLowerCase();
}

// Is this column a number column? (Development, Functional, Total ...)
function isNumberColumn(col) {
  return COLUMNS[col].number;
}


// ============================================================
// 1. Filters
// ============================================================

// Does this row pass the column filters and the search box?
// skipColumn: leave out the filter of this one column (used by the cascading filter menu)
function rowPasses(row, skipColumn) {
  for (const col in columnFilters) {
    if (col === skipColumn) {
      continue;
    }
    const cell = getCell(row, col);
    if (!columnFilters[col].includes(filterValue(cell))) {
      return false;
    }
  }
  if (searchText !== "" && !row.textContent.toLowerCase().includes(searchText)) {
    return false;
  }
  return true;
}

// Shows or hides every row, using the column filters and the search box
function applyAllFilters() {
  let shown = 0;
  for (const row of getRows()) {
    const keep = rowPasses(row, null);
    row.hidden = !keep;
    if (keep) {
      shown = shown + 1;
    }
  }

  document.getElementById("shown-count").textContent = shown;
  document.getElementById("no-rows").hidden = (shown > 0);
  markFilteredHeaders();
}

// Filtered columns get a blue filter icon in the header
function markFilteredHeaders() {
  for (const header of document.querySelectorAll(".name-row th[data-col]")) {
    const filtered = header.dataset.col in columnFilters;
    header.classList.toggle("filtered", filtered);
  }
}

// Opens the filter menu under the filter icon that was clicked.
// Cascading: it lists only the values in the rows that the OTHER filters leave.
// Example: Topic Group = FG  ->  the IO Lead menu shows only the IO leads of FG rows.
function openFilterMenu(button) {
  openColumn = button.dataset.col;

  const labels = {};
  for (const row of getRows()) {
    if (!rowPasses(row, openColumn)) {
      continue;
    }
    const cell = getCell(row, openColumn);
    const key = filterValue(cell);
    if (!(key in labels)) {
      labels[key] = cell.dataset.value.trim() || "(Blanks)";
    }
  }

  // Sort the values A to Z (numbers by size), blanks last
  let keys = Object.keys(labels);
  keys.sort(function (a, b) {
    if (a === "(blanks)") return 1;
    if (b === "(blanks)") return -1;
    if (isNumberColumn(openColumn)) return parseFloat(a) - parseFloat(b);
    return a.localeCompare(b);
  });

  // Build the list of checkboxes (no counts, like Excel)
  const list = document.getElementById("menu-values");
  let html = '<label class="menu-value select-all"><input type="checkbox" id="select-all" onchange="tickAll(this.checked)"> (Select All)</label>';
  for (const key of keys) {
    let ticked = true;
    if (openColumn in columnFilters) {
      ticked = columnFilters[openColumn].includes(key);
    }
    html += '<label class="menu-value"><input type="checkbox" class="value-box" value="' + escapeText(key) + '"'
          + (ticked ? " checked" : "") + ' onchange="updateSelectAll()"> '
          + escapeText(labels[key]) + '</label>';
  }
  list.innerHTML = html;
  menuLabels = labels;
  updateSelectAll();
  document.getElementById("menu-search").value = "";

  // Put the menu just under the button (but never outside the screen)
  const menu = document.getElementById("filter-menu");
  const place = button.getBoundingClientRect();
  menu.hidden = false;
  let left = place.right - menu.offsetWidth;
  if (left < 8) left = 8;
  menu.style.left = left + "px";
  menu.style.top = (place.bottom + 4) + "px";

  // Small screen? Make the menu shorter so the buttons are always visible
  const space = window.innerHeight - (place.bottom + 4) - 16;
  menu.style.maxHeight = space + "px";
  if (space < 260) {
    menu.style.top = "10px";
    menu.style.maxHeight = (window.innerHeight - 20) + "px";
  }
}

function closeFilterMenu() {
  document.getElementById("filter-menu").hidden = true;
  openColumn = null;
}

// (Select All) ticks or unticks every visible value
function tickAll(checked) {
  for (const box of document.querySelectorAll(".value-box")) {
    if (!box.parentElement.hidden) {
      box.checked = checked;
    }
  }
}

// (Select All) shows ✓ when all are ticked, – when only some are ticked
function updateSelectAll() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = boxes.filter(function (box) { return box.checked; }).length;
  const selectAll = document.getElementById("select-all");
  selectAll.checked = (ticked === boxes.length);
  selectAll.indeterminate = (ticked > 0 && ticked < boxes.length);
}

// The search box inside the menu hides values that don't match
function searchMenuValues() {
  const text = document.getElementById("menu-search").value.toLowerCase();
  for (const box of document.querySelectorAll(".value-box")) {
    box.parentElement.hidden = !box.value.includes(text);
  }
}

// OK button: remember the ticked values for this column
function applyColumnFilter() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = [];
  const tickedLabels = [];
  for (const box of boxes) {
    if (box.checked) {
      ticked.push(box.value);
      tickedLabels.push(menuLabels[box.value]);
    }
  }

  if (ticked.length === boxes.length) {
    delete columnFilters[openColumn];     // everything ticked = no filter
  } else {
    columnFilters[openColumn] = ticked;
    filterLabels[openColumn] = tickedLabels;
  }
  closeFilterMenu();
  applyAllFilters();
}

function clearColumnFilter() {
  delete columnFilters[openColumn];
  closeFilterMenu();
  applyAllFilters();
}

// Sort A to Z (direction 1) or Z to A (direction -1)
function sortColumn(direction) {
  const col = openColumn;
  const number = isNumberColumn(col);
  const rows = getRows();

  rows.sort(function (rowA, rowB) {
    const a = getCell(rowA, col).dataset.value.trim();
    const b = getCell(rowB, col).dataset.value.trim();
    if (a === "" && b !== "") return 1;      // blanks always at the bottom
    if (b === "" && a !== "") return -1;
    if (number) return (parseFloat(a) - parseFloat(b)) * direction;
    return a.localeCompare(b) * direction;
  });

  const body = document.querySelector("#sheet tbody");
  for (const row of rows) {
    body.appendChild(row);                   // moving a row puts it at the end, so this re-orders them
  }
  closeFilterMenu();
}

// Clear sort: put the rows back in the Excel order (by the row number on the left)
function clearSort() {
  const rows = getRows();
  rows.sort(function (rowA, rowB) {
    return Number(rowA.querySelector(".row-number").textContent) - Number(rowB.querySelector(".row-number").textContent);
  });
  const body = document.querySelector("#sheet tbody");
  for (const row of rows) {
    body.appendChild(row);
  }
  closeFilterMenu();
}

// Makes text safe to put inside HTML
function escapeText(text) {
  const box = document.createElement("span");
  box.textContent = text;
  return box.innerHTML.replace(/"/g, "&quot;");
}


// ============================================================
// 2. Editing a cell: type in the cell, pick from the list under it
// ============================================================

// Every value used in one column, with how many rows use it:  [{ value: "FG", count: 38 }, ...]
function getColumnValues(col) {
  const counts = {};
  const spelling = {};
  for (const row of getRows()) {
    const value = getCell(row, col).dataset.value.trim();
    if (value === "") {
      continue;
    }
    const key = value.toLowerCase();            // "FG" and "fg" are the same value
    if (!(key in counts)) {
      counts[key] = 0;
      spelling[key] = value;
    }
    counts[key] = counts[key] + 1;
  }

  const list = [];
  for (const key in counts) {
    list.push({ value: spelling[key], count: counts[key] });
  }
  list.sort(function (a, b) {
    if (isNumberColumn(col)) return Number(a.value) - Number(b.value);
    return a.value.localeCompare(b.value);
  });
  return list;
}

// Click on an editable cell -> the cell becomes a text box and the list opens under it
function startEdit(cell) {
  if (editCell === cell) {
    return;                                    // already editing this cell
  }
  if (editCell) {
    cancelEdit();
  }

  // Remember the value (and the look, e.g. a badge) from the Excel, the first time
  if (cell.dataset.original === undefined) {
    cell.dataset.original = cell.dataset.value;
    cell.originalHtml = cell.innerHTML;
  }

  editCell = cell;
  editTyped = false;
  editInput = document.createElement("input");
  editInput.type = "text";
  editInput.className = "cell-editor";
  editInput.value = cell.dataset.value;

  cell.classList.add("editing");
  cell.innerHTML = "";
  const box = document.createElement("div");
  box.className = "cell-box";
  box.appendChild(editInput);
  box.insertAdjacentHTML("beforeend", '<svg class="cell-arrow up" viewBox="0 0 24 24"><path d="M6 15l6-6 6 6"/></svg>');
  cell.appendChild(box);

  editInput.oninput = function () {
    editTyped = true;
    showCellList();
  };
  editInput.onkeydown = function (event) {
    if (event.key === "ArrowDown") { moveHighlight(1); event.preventDefault(); }
    if (event.key === "ArrowUp") { moveHighlight(-1); event.preventDefault(); }
    if (event.key === "Enter" || event.key === "Tab") { pickHighlighted(); event.preventDefault(); }
    if (event.key === "Escape") { cancelEdit(); }
  };
  editInput.onblur = function () {
    cancelEdit();                              // clicking somewhere else = no change
  };

  editInput.focus();
  editInput.select();                          // so typing replaces the old value
  showCellList();
}

// Builds the list under the cell: the values that contain what you typed
function showCellList() {
  const col = editCell.dataset.col;
  const typed = editTyped ? editInput.value.trim() : "";
  const lowerTyped = typed.toLowerCase();
  const current = editCell.dataset.value.trim().toLowerCase();

  editChoices = [];
  let html = "";
  let exactMatch = false;
  editPick = 0;

  // Nothing typed -> "— Blank —" on top, to empty the cell
  if (typed === "") {
    if (current === "") {
      editPick = 0;
    }
    editChoices.push({ value: "" });
    html += '<div class="cell-option blank-value"><span>— Blank —</span>' + (current === "" ? "<b>&#10003;</b>" : "") + '</div>';
  }

  for (const item of getColumnValues(col)) {
    const lower = item.value.toLowerCase();
    if (lowerTyped !== "" && !lower.includes(lowerTyped)) {
      continue;
    }
    if (lower === lowerTyped) {
      exactMatch = true;
    }
    if (!editTyped && lower === current) {
      editPick = editChoices.length;           // start on the value that is in the cell now
    }
    editChoices.push({ value: item.value });
    html += '<div class="cell-option' + (lower === current ? " current" : "") + '">'
          + '<span>' + markText(item.value, typed) + '</span>'
          + (lower === current ? "<b>&#10003;</b>" : "") + '</div>';
  }

  // Typed something that is not in the list -> offer it as a new value (numbers only in number columns)
  if (typed !== "" && !exactMatch) {
    const okNumber = !isNumberColumn(col) || !isNaN(Number(typed));
    if (okNumber) {
      editChoices.push({ value: typed });
      html += '<div class="cell-option new-value"><span>+ Use &ldquo;<b>' + escapeText(typed) + '</b>&rdquo; as a new value</span></div>';
    } else if (editChoices.length === 0) {
      html += '<div class="cell-none">Please type a number</div>';
    }
  }

  if (html === "") {
    html = '<div class="cell-none">No values yet - type one</div>';
  }

  document.getElementById("cell-options").innerHTML = html;

  // Click on a line = pick it.  "mousedown" comes before the text box loses focus.
  const lines = document.querySelectorAll("#cell-options .cell-option");
  lines.forEach(function (line, index) {
    line.onmousedown = function (event) {
      event.preventDefault();
      editPick = index;
      pickHighlighted();
    };
  });

  highlightLine();
  placeCellList();
}

// Puts the list just under the cell (or above it when there is no room below)
function placeCellList() {
  const list = document.getElementById("cell-list");
  const place = editCell.getBoundingClientRect();
  list.hidden = false;
  list.style.width = Math.min(Math.max(place.width, 190), 260) + "px";

  let left = place.left;
  if (left + list.offsetWidth > window.innerWidth - 8) {
    left = window.innerWidth - 8 - list.offsetWidth;
  }
  list.style.left = left + "px";

  const below = window.innerHeight - place.bottom - 12;
  if (below >= list.offsetHeight || below >= place.top) {
    list.style.top = (place.bottom + 2) + "px";
    list.style.maxHeight = below + "px";
  } else {
    list.style.top = Math.max(8, place.top - 2 - list.offsetHeight) + "px";
    list.style.maxHeight = (place.top - 12) + "px";
  }
}

// Arrow keys move the blue line up and down
function moveHighlight(step) {
  if (editChoices.length === 0) return;
  editPick = (editPick + step + editChoices.length) % editChoices.length;
  highlightLine();
}

function highlightLine() {
  const lines = document.querySelectorAll("#cell-options .cell-option");
  lines.forEach(function (line, index) {
    line.classList.toggle("active", index === editPick);
    if (index === editPick) {
      line.scrollIntoView({ block: "nearest" });
    }
  });
}

// Enter (or a click) puts the highlighted value in the cell
function pickHighlighted() {
  if (editChoices.length === 0) {
    return;
  }
  finishEdit(editCell, editChoices[editPick].value);
}

// Esc or clicking somewhere else: keep the value the cell had
function cancelEdit() {
  if (editCell) {
    finishEdit(editCell, editCell.dataset.value);
  }
}

// Shows the typed letters in yellow:  "Procurement" + "proc" -> "<u>Proc</u>urement"
function markText(text, typed) {
  if (typed === "") {
    return escapeText(text);
  }
  const start = text.toLowerCase().indexOf(typed.toLowerCase());
  if (start < 0) {
    return escapeText(text);
  }
  return escapeText(text.slice(0, start))
       + "<u>" + escapeText(text.slice(start, start + typed.length)) + "</u>"
       + escapeText(text.slice(start + typed.length));
}

// Puts the new value in the cell and remembers the change
function finishEdit(cell, newValue) {
  if (!cell.classList.contains("editing")) {
    return;
  }
  cell.classList.remove("editing");
  editCell = null;
  editInput = null;
  document.getElementById("cell-list").hidden = true;

  newValue = String(newValue).trim();
  cell.dataset.value = newValue;
  cell.title = newValue;

  const row = cell.parentElement;
  const col = cell.dataset.col;
  const key = row.dataset.id + "_" + col;
  const oldValue = cell.dataset.original;

  // Did it really change? (numbers: 30 and 30.0 are the same)
  let changed = (newValue !== oldValue);
  if (isNumberColumn(col)) {
    changed = (Number(newValue || 0) !== Number(oldValue || 0));
  }

  if (changed) {
    changes[key] = {
      id: row.dataset.id,
      col: col,
      row: row.querySelector(".row-number").textContent,
      oldValue: oldValue,
      newValue: newValue,
    };
  } else {
    delete changes[key];
  }

  showCellValue(cell, changed ? oldValue : null);

  // Development or Functional changed -> Total Effort = Development + Functional (like the Excel formula)
  if (col == FORMULA_COLUMNS.dev || col == FORMULA_COLUMNS.func) {
    updateTotal(row);
  }
  updateSaveBar();
}

// Shows the value in the cell. A changed cell is yellow and shows the old value.
function showCellValue(cell, oldValue) {
  cell.classList.toggle("changed", oldValue !== null);

  // Not changed: put back exactly what the Excel showed (badges too)
  if (oldValue === null) {
    cell.innerHTML = cell.originalHtml;
    return;
  }

  const value = cell.dataset.value;
  let html = '<div class="cell-box"><span class="cell-text">';
  html += (value === "") ? '<span class="empty">—</span>' : escapeText(value);
  html += '<i class="was">was ' + escapeText(oldValue === "" ? "blank" : oldValue) + '</i></span>';
  html += '<svg class="cell-arrow" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></div>';
  cell.innerHTML = html;
}

// Recalculates the Total Effort cell of one row
function updateTotal(row) {
  const devCell = getCell(row, FORMULA_COLUMNS.dev);
  const funcCell = getCell(row, FORMULA_COLUMNS.func);
  const totalCell = getCell(row, FORMULA_COLUMNS.total);
  if (!devCell || !funcCell || !totalCell) {
    return;
  }
  const total = Number(devCell.dataset.value || 0) + Number(funcCell.dataset.value || 0);
  totalCell.dataset.value = String(total);
  totalCell.querySelector(".cell-text").textContent = total;
}


// ============================================================
// 3. Save bar
// ============================================================

// Shows how many cells changed, and puts one hidden box per change in the form
function updateSaveBar() {
  const list = Object.values(changes);
  const form = document.getElementById("save-form");
  form.hidden = (list.length === 0);

  document.getElementById("change-count").textContent =
    list.length + (list.length === 1 ? " unsaved change" : " unsaved changes");

  // A short summary:  "Row 6: Development 30 → 35 · Row 8: Business Confirmation"
  const parts = [];
  for (const change of list) {
    let text = "Row " + change.row + ": " + COLUMNS[change.col].name;
    if (isNumberColumn(change.col)) {
      text += " " + (change.oldValue || 0) + " → " + (change.newValue || 0);
    }
    parts.push(text);
  }
  document.getElementById("change-list").textContent = parts.join(" · ");

  // The boxes Python reads:  cell_<id>_<column number>
  const boxes = document.getElementById("save-boxes");
  boxes.innerHTML = "";
  for (const change of list) {
    const box = document.createElement("input");
    box.type = "hidden";
    box.name = "cell_" + change.id + "_" + change.col;
    box.value = change.newValue;
    boxes.appendChild(box);
  }
}

// Discard: load the page again (nothing was saved yet)
function discardChanges() {
  changes = {};
  location.reload();
}


// ============================================================
// 4. Columns menu: tick = show the column, untick = hide it
// ============================================================

// The columns that the Excel file shows (the start view)
function getExcelColumns() {
  const list = [];
  for (const col in COLUMNS) {
    if (COLUMNS[col].inExcel) {
      list.push(col);
    }
  }
  return list;
}

// Hides and shows the columns, and gives the table its width
function showColumns() {
  // 1. Every header cell and every cell gets the class "column-hidden" or not
  for (const cell of document.querySelectorAll("#sheet [data-col]")) {
    cell.classList.toggle("column-hidden", !shownColumns.includes(cell.dataset.col));
  }

  // 2. The <colgroup> (column widths) only has the shown columns
  let html = '<col style="width: 38px">';
  let width = 38;
  for (const col in COLUMNS) {
    if (shownColumns.includes(col)) {
      html += '<col style="width: ' + COLUMNS[col].width + 'px">';
      width = width + COLUMNS[col].width;
    }
  }
  document.getElementById("sheet-cols").innerHTML = html;
  document.getElementById("sheet").style.width = width + "px";

  // 3. The button shows "21 / 37"
  document.getElementById("columns-count").textContent = shownColumns.length + " / " + Object.keys(COLUMNS).length;

  // 4. Remember the choice for one year in a cookie, e.g. "0-1-2-5" (Python reads it next time)
  document.cookie = "mbbp_columns=" + shownColumns.join("-") + "; max-age=31536000; path=/";
}

// Opens the menu with a tick for every shown column
function openColumnsMenu() {
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = shownColumns.includes(box.value);
    box.parentElement.hidden = false;
  }
  document.getElementById("columns-find").value = "";
  countTickedColumns();

  const menu = document.getElementById("columns-menu");
  const place = document.getElementById("columns-button").getBoundingClientRect();
  menu.hidden = false;
  menu.style.top = (place.bottom + 6) + "px";
  menu.style.left = Math.max(8, place.right - menu.offsetWidth) + "px";
  menu.style.maxHeight = (window.innerHeight - place.bottom - 16) + "px";
}

function closeColumnsMenu() {
  document.getElementById("columns-menu").hidden = true;
}

// "21 of 37 shown", and the Select all box: ✓, – or empty
function countTickedColumns() {
  const boxes = Array.from(document.querySelectorAll(".column-box"));
  const ticked = boxes.filter(function (box) { return box.checked; }).length;
  document.getElementById("columns-ticked").textContent = ticked;
  const selectAll = document.getElementById("columns-select-all");
  selectAll.checked = (ticked === boxes.length);
  selectAll.indeterminate = (ticked > 0 && ticked < boxes.length);
}

function tickAllColumns(checked) {
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = checked;
  }
  countTickedColumns();
}

// "Excel default": tick only the columns the Excel file shows
function tickExcelColumns() {
  const excel = getExcelColumns();
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = excel.includes(box.value);
  }
  countTickedColumns();
}

// The search box in the menu hides column names that don't match
function findColumn() {
  const text = document.getElementById("columns-find").value.toLowerCase();
  for (const box of document.querySelectorAll(".column-box")) {
    box.parentElement.hidden = !box.parentElement.textContent.toLowerCase().includes(text);
  }
}

// Apply: show the ticked columns
function applyColumns() {
  const ticked = [];
  for (const box of document.querySelectorAll(".column-box")) {
    if (box.checked) {
      ticked.push(box.value);
    }
  }
  if (ticked.length === 0) {
    alert("Please tick at least one column.");
    return;
  }
  shownColumns = ticked;
  closeColumnsMenu();
  showColumns();
}


// ============================================================
// Connect the functions to clicks and typing
// ============================================================

// Click a filter icon -> open its menu.  Click outside a menu -> close it.
document.addEventListener("click", function (event) {
  const button = event.target.closest(".filter-button");
  if (button) {
    closeColumnsMenu();
    openFilterMenu(button);
    return;
  }
  if (event.target.closest("#columns-button")) {
    closeFilterMenu();
    if (document.getElementById("columns-menu").hidden) {
      openColumnsMenu();
    } else {
      closeColumnsMenu();
    }
    return;
  }
  if (!event.target.closest("#filter-menu")) {
    closeFilterMenu();
  }
  if (!event.target.closest("#columns-menu")) {
    closeColumnsMenu();
  }
});

// Click an editable cell -> edit it
document.querySelector("#sheet tbody").addEventListener("click", function (event) {
  const cell = event.target.closest("td.editable");
  if (cell) {
    startEdit(cell);
  }
});

// Scrolling the table moves the cell away from its list -> stop editing
document.querySelector(".sheet-box").addEventListener("scroll", function () {
  cancelEdit();
});

// Type in "Search" -> filter the rows
document.getElementById("table-search").addEventListener("input", function (event) {
  searchText = event.target.value.toLowerCase().trim();
  applyAllFilters();
});

// Saving: no warning.  Leaving the page with unsaved changes: ask first.
let saving = false;
document.getElementById("save-form").addEventListener("submit", function () {
  saving = true;
});
window.addEventListener("beforeunload", function (event) {
  if (!saving && Object.keys(changes).length > 0) {
    event.preventDefault();
    event.returnValue = "";
  }
});

// Start: Python already hid the columns you unticked last time. Just remember which ones are shown.
for (const col in COLUMNS) {
  if (COLUMNS[col].shown) {
    shownColumns.push(col);
  }
}
document.getElementById("columns-count").textContent = shownColumns.length + " / " + Object.keys(COLUMNS).length;
