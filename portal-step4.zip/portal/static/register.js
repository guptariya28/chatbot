// ============================================================
// register.js - makes the Demand register work like Excel
//
//   1. Filter icon in a header -> filter menu (sort, search, tick values)
//   2. Click a cell            -> type in the cell, a list of matching values opens under it
//                                 (stakeholders list / business group: a tick list, several names per cell)
//   3. Save bar                -> sends the changed cells to Python (/register/save)
//   4. Columns button          -> tick the columns you want to see
//
// Python still does the saving, the permissions and the change log.
// This file only changes what you see in the browser.
// ============================================================


// ---------- What we remember while the page is open ----------

let columnFilters = {};   // column number -> list of ticked values,  e.g. { "2": ["fg", "controlling"] }
let filterLabels = {};    // column number -> the same values as shown,  e.g. { "2": ["FG", "Controlling"] }
let menuLabels = {};      // value -> label, for the menu that is open now
let changes = {};         // "id_column" -> { id, col, row, oldValue, newValue }
let openColumn = null;    // the column whose filter menu is open
let searchText = "";      // text in the "Search" box
let shownColumns = [];    // column numbers that are shown (the rest is hidden)

// The cell being edited
let editCell = null;      // the <td>
let editInput = null;     // the text box inside it
let editTyped = false;    // false = nothing typed yet, so the list shows every value
let editChoices = [];     // the values in the list now:  [{ value, isNew }]
let editPick = 0;         // which line of the list is highlighted
let tickedNames = [];     // tick list: the names ticked now,  e.g. ["Charan", "Jeet"]
let tickOrder = [];       // tick list: the order of the lines (ticked names first, then the rest A to Z)


// ---------- Small helpers ----------

// All table rows (the <tr> elements in the body)
function getRows() {
  return Array.from(document.querySelectorAll("#sheet tbody tr"));
}

// One cell of a row, found by its column number
function getCell(row, col) {
  return row.querySelector('td[data-col="' + col + '"]');
}

// The value we filter on: small letters, and "(blanks)" for an empty cell
function filterValue(cell) {
  const value = cell.dataset.value.trim();
  if (value === "") {
    return "(blanks)";
  }
  return value.toLowerCase();
}

// Is this column a number column? (Development, Functional, Total ...)
function isNumberColumn(col) {
  return COLUMNS[col].number;
}


// ---------- Master lists (from the master sheets in the Excel) ----------

// Can this column hold several names, like "Charan, Jeet"? (stakeholders list, business group)
function isMultiColumn(col) {
  return col in MASTERS && MASTERS[col].multi;
}

// "Charan, Jeet" -> ["Charan", "Jeet"]
function splitNames(text) {
  const names = [];
  for (const part of text.split(",")) {
    if (part.trim() !== "") {
      names.push(part.trim());
    }
  }
  return names;
}

// Makes two names comparable: small letters, and every space the same.
// Excel cells often hide extra spaces: "Ashwin  Nagarajan" (2 spaces), a space at the end,
// or a "non-breaking space" copied from email/web. All of these count as the same name.
function sameName(text) {
  return String(text)
    .replace(/[\u200B-\u200D\uFEFF]/g, "")   // invisible characters
    .replace(/\s+/g, " ")                      // many / special spaces -> one normal space
    .trim()
    .toLowerCase();
}

// Is this name in the master list of the column? (small/capital letters and extra spaces don't matter)
function inMaster(col, name) {
  const wanted = sameName(name);
  return MASTERS[col].names.some(function (masterName) {
    return sameName(masterName) === wanted;
  });
}

// The names in a cell that are NOT in the master list
function namesNotInMaster(col, value) {
  let names = [value.trim()];
  if (isMultiColumn(col)) {
    names = splitNames(value);
  }
  return names.filter(function (name) {
    return name !== "" && !inMaster(col, name);
  });
}

// A value that is not in the master is kept, but shown in orange (so you can fix it)
//   one name   : "Arpan  [not in master]"
//   many names : only the unknown names are orange:  "Charan, Ravi K"
function markMaster(cell) {
  const col = cell.dataset.col;
  const text = cell.querySelector(".cell-text");
  if (!(col in MASTERS) || !text) {
    return;
  }
  const oldTag = text.querySelector(".nm-tag");
  if (oldTag) {
    oldTag.remove();
  }

  const unknown = namesNotInMaster(col, cell.dataset.value);
  cell.classList.toggle("not-master", unknown.length > 0);
  cell.classList.toggle("multi-names", isMultiColumn(col));
  if (unknown.length === 0) {
    cell.title = cell.dataset.value;
    return;
  }
  cell.title = cell.dataset.value + "\nNot in the " + MASTERS[col].sheet + " master: " + unknown.join(", ");

  if (isMultiColumn(col)) {
    const was = text.querySelector(".was");        // "was ..." of a changed cell
    const parts = [];
    for (const name of splitNames(cell.dataset.value)) {
      parts.push(inMaster(col, name) ? escapeText(name) : '<span class="nm-name">' + escapeText(name) + '</span>');
    }
    text.innerHTML = parts.join(", ") + (was ? was.outerHTML : "");
  } else {
    text.insertAdjacentHTML("beforeend", '<span class="nm-tag">not in master</span>');
  }
}

// The values we filter on for one cell (small letters).
// Many-names cells give every name:  "Charan, Jeet" -> ["charan", "jeet"]
function filterKeys(cell) {
  if (isMultiColumn(cell.dataset.col)) {
    const names = splitNames(cell.dataset.value);
    if (names.length === 0) {
      return ["(blanks)"];
    }
    return names.map(function (name) { return name.toLowerCase(); });
  }
  return [filterValue(cell)];
}

// The same values, as they are written (for the filter menu)
function filterLabelsOf(cell) {
  if (isMultiColumn(cell.dataset.col)) {
    const names = splitNames(cell.dataset.value);
    return names.length === 0 ? ["(Blanks)"] : names;
  }
  return [cell.dataset.value.trim() || "(Blanks)"];
}


// ============================================================
// 1. Filters
// ============================================================

// Does this row pass the column filters and the search box?
// skipColumn: leave out the filter of this one column (used by the cascading filter menu)
function rowPasses(row, skipColumn) {
  for (const col in columnFilters) {
    if (col === skipColumn) {
      continue;
    }
    // the row passes if ONE of its values is ticked ("Charan" finds "Charan, Jeet" too)
    const keys = filterKeys(getCell(row, col));
    const ticked = keys.some(function (key) { return columnFilters[col].includes(key); });
    if (!ticked) {
      return false;
    }
  }
  if (searchText !== "" && !row.textContent.toLowerCase().includes(searchText)) {
    return false;
  }
  return true;
}

// Shows or hides every row, using the column filters and the search box
function applyAllFilters() {
  let shown = 0;
  for (const row of getRows()) {
    const keep = rowPasses(row, null);
    row.hidden = !keep;
    if (keep) {
      shown = shown + 1;
    }
  }

  document.getElementById("shown-count").textContent = shown;
  document.getElementById("no-rows").hidden = (shown > 0);
  markFilteredHeaders();
}

// Filtered columns get a blue filter icon in the header
function markFilteredHeaders() {
  for (const header of document.querySelectorAll(".name-row th[data-col]")) {
    const filtered = header.dataset.col in columnFilters;
    header.classList.toggle("filtered", filtered);
  }
}

// Opens the filter menu under the filter icon that was clicked.
// Cascading: it lists only the values in the rows that the OTHER filters leave.
// Example: Topic Group = FG  ->  the IO Lead menu shows only the IO leads of FG rows.
function openFilterMenu(button) {
  openColumn = button.dataset.col;

  const labels = {};
  for (const row of getRows()) {
    if (!rowPasses(row, openColumn)) {
      continue;
    }
    const cell = getCell(row, openColumn);
    const keys = filterKeys(cell);                 // many-names cells: every name once
    const names = filterLabelsOf(cell);
    keys.forEach(function (key, index) {
      if (!(key in labels)) {
        labels[key] = names[index];
      }
    });
  }

  // Sort the values A to Z (numbers by size), blanks last
  let keys = Object.keys(labels);
  keys.sort(function (a, b) {
    if (a === "(blanks)") return 1;
    if (b === "(blanks)") return -1;
    if (isNumberColumn(openColumn)) return parseFloat(a) - parseFloat(b);
    return a.localeCompare(b);
  });

  // Build the list of checkboxes (no counts, like Excel)
  const list = document.getElementById("menu-values");
  let html = '<label class="menu-value select-all"><input type="checkbox" id="select-all" onchange="tickAll(this.checked)"> (Select All)</label>';
  for (const key of keys) {
    let ticked = true;
    if (openColumn in columnFilters) {
      ticked = columnFilters[openColumn].includes(key);
    }
    html += '<label class="menu-value"><input type="checkbox" class="value-box" value="' + escapeText(key) + '"'
          + (ticked ? " checked" : "") + ' onchange="updateSelectAll()"> '
          + escapeText(labels[key]) + '</label>';
  }
  list.innerHTML = html;
  menuLabels = labels;
  updateSelectAll();
  document.getElementById("menu-search").value = "";

  // Put the menu just under the button (but never outside the screen)
  const menu = document.getElementById("filter-menu");
  const place = button.getBoundingClientRect();
  menu.hidden = false;
  let left = place.right - menu.offsetWidth;
  if (left < 8) left = 8;
  menu.style.left = left + "px";
  menu.style.top = (place.bottom + 4) + "px";

  // Small screen? Make the menu shorter so the buttons are always visible
  const space = window.innerHeight - (place.bottom + 4) - 16;
  menu.style.maxHeight = space + "px";
  if (space < 260) {
    menu.style.top = "10px";
    menu.style.maxHeight = (window.innerHeight - 20) + "px";
  }
}

function closeFilterMenu() {
  document.getElementById("filter-menu").hidden = true;
  openColumn = null;
}

// (Select All) ticks or unticks every visible value
function tickAll(checked) {
  for (const box of document.querySelectorAll(".value-box")) {
    if (!box.parentElement.hidden) {
      box.checked = checked;
    }
  }
}

// (Select All) shows ✓ when all are ticked, – when only some are ticked
function updateSelectAll() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = boxes.filter(function (box) { return box.checked; }).length;
  const selectAll = document.getElementById("select-all");
  selectAll.checked = (ticked === boxes.length);
  selectAll.indeterminate = (ticked > 0 && ticked < boxes.length);
}

// The search box inside the menu hides values that don't match
function searchMenuValues() {
  const text = document.getElementById("menu-search").value.toLowerCase();
  for (const box of document.querySelectorAll(".value-box")) {
    box.parentElement.hidden = !box.value.includes(text);
  }
}

// OK button: remember the ticked values for this column
function applyColumnFilter() {
  const boxes = Array.from(document.querySelectorAll(".value-box"));
  const ticked = [];
  const tickedLabels = [];
  for (const box of boxes) {
    if (box.checked) {
      ticked.push(box.value);
      tickedLabels.push(menuLabels[box.value]);
    }
  }

  if (ticked.length === boxes.length) {
    delete columnFilters[openColumn];     // everything ticked = no filter
  } else {
    columnFilters[openColumn] = ticked;
    filterLabels[openColumn] = tickedLabels;
  }
  closeFilterMenu();
  applyAllFilters();
}

function clearColumnFilter() {
  delete columnFilters[openColumn];
  closeFilterMenu();
  applyAllFilters();
}

// Sort A to Z (direction 1) or Z to A (direction -1)
function sortColumn(direction) {
  const col = openColumn;
  const number = isNumberColumn(col);
  const rows = getRows();

  rows.sort(function (rowA, rowB) {
    const a = getCell(rowA, col).dataset.value.trim();
    const b = getCell(rowB, col).dataset.value.trim();
    if (a === "" && b !== "") return 1;      // blanks always at the bottom
    if (b === "" && a !== "") return -1;
    if (number) return (parseFloat(a) - parseFloat(b)) * direction;
    return a.localeCompare(b) * direction;
  });

  const body = document.querySelector("#sheet tbody");
  for (const row of rows) {
    body.appendChild(row);                   // moving a row puts it at the end, so this re-orders them
  }
  closeFilterMenu();
}

// Clear sort: put the rows back in the Excel order (by the row number on the left)
function clearSort() {
  const rows = getRows();
  rows.sort(function (rowA, rowB) {
    return Number(rowA.querySelector(".row-number").textContent) - Number(rowB.querySelector(".row-number").textContent);
  });
  const body = document.querySelector("#sheet tbody");
  for (const row of rows) {
    body.appendChild(row);
  }
  closeFilterMenu();
}

// Makes text safe to put inside HTML
function escapeText(text) {
  const box = document.createElement("span");
  box.textContent = text;
  return box.innerHTML.replace(/"/g, "&quot;");
}


// ============================================================
// 2. Editing a cell: type in the cell, pick from the list under it
// ============================================================

// Every value used in one column, with how many rows use it:  [{ value: "FG", count: 38 }, ...]
// Columns with a master sheet (IO Lead, Reporter ...) give the master names instead.
function getColumnValues(col) {
  if (col in MASTERS) {
    return MASTERS[col].names.map(function (name) { return { value: name }; });
  }
  const counts = {};
  const spelling = {};
  for (const row of getRows()) {
    const value = getCell(row, col).dataset.value.trim();
    if (value === "") {
      continue;
    }
    const key = value.toLowerCase();            // "FG" and "fg" are the same value
    if (!(key in counts)) {
      counts[key] = 0;
      spelling[key] = value;
    }
    counts[key] = counts[key] + 1;
  }

  const list = [];
  for (const key in counts) {
    list.push({ value: spelling[key], count: counts[key] });
  }
  list.sort(function (a, b) {
    if (isNumberColumn(col)) return Number(a.value) - Number(b.value);
    return a.value.localeCompare(b.value);
  });
  return list;
}

// Click on an editable cell -> the cell becomes a text box and the list opens under it
function startEdit(cell) {
  if (editCell === cell) {
    return;                                    // already editing this cell
  }
  if (editCell) {
    cancelEdit();
  }

  // Remember the value (and the look, e.g. a badge) from the Excel, the first time
  if (cell.dataset.original === undefined) {
    cell.dataset.original = cell.dataset.value;
    cell.originalHtml = cell.innerHTML;
  }

  // stakeholders list / business group -> tick list
  if (isMultiColumn(cell.dataset.col)) {
    startTickEdit(cell);
    return;
  }

  editCell = cell;
  editTyped = false;
  editInput = document.createElement("input");
  editInput.type = "text";
  editInput.className = "cell-editor";
  editInput.value = cell.dataset.value;

  cell.classList.add("editing");
  cell.innerHTML = "";
  const box = document.createElement("div");
  box.className = "cell-box";
  box.appendChild(editInput);
  box.insertAdjacentHTML("beforeend", '<svg class="cell-arrow up" viewBox="0 0 24 24"><path d="M6 15l6-6 6 6"/></svg>');
  cell.appendChild(box);

  editInput.oninput = function () {
    editTyped = true;
    showCellList();
  };
  editInput.onkeydown = function (event) {
    if (event.key === "ArrowDown") { moveHighlight(1); event.preventDefault(); }
    if (event.key === "ArrowUp") { moveHighlight(-1); event.preventDefault(); }
    if (event.key === "Enter" || event.key === "Tab") { pickHighlighted(); event.preventDefault(); }
    if (event.key === "Escape") { cancelEdit(); }
  };
  editInput.onblur = function () {
    cancelEdit();                              // clicking somewhere else = no change
  };

  editInput.focus();
  editInput.select();                          // so typing replaces the old value
  showCellList();
}

// Builds the list under the cell: the values that contain what you typed
function showCellList() {
  const col = editCell.dataset.col;
  const typed = editTyped ? editInput.value.trim() : "";
  const lowerTyped = typed.toLowerCase();
  const current = editCell.dataset.value.trim().toLowerCase();

  editChoices = [];
  let html = "";
  let exactMatch = false;
  editPick = 0;
  const master = MASTERS[col];                   // undefined = no master sheet for this column

  // Master column: a small line on top "From master IO Leads · 8 names"
  const head = document.getElementById("cell-head");
  head.hidden = !master;
  if (master) {
    head.innerHTML = '<span>From master <b>' + escapeText(master.sheet) + '</b></span><span>' + master.names.length + ' names</span>';
  }

  // Nothing typed -> "— Blank —" on top, to empty the cell
  if (typed === "") {
    if (current === "") {
      editPick = 0;
    }
    editChoices.push({ value: "" });
    html += '<div class="cell-option blank-value"><span>— Blank —</span>' + (current === "" ? "<b>&#10003;</b>" : "") + '</div>';
  }

  for (const item of getColumnValues(col)) {
    const lower = item.value.toLowerCase();
    if (lowerTyped !== "" && !lower.includes(lowerTyped)) {
      continue;
    }
    if (lower === lowerTyped) {
      exactMatch = true;
    }
    if (!editTyped && lower === current) {
      editPick = editChoices.length;           // start on the value that is in the cell now
    }
    editChoices.push({ value: item.value });
    html += '<div class="cell-option' + (lower === current ? " current" : "") + '">'
          + '<span>' + markText(item.value, typed) + '</span>'
          + (lower === current ? "<b>&#10003;</b>" : "") + '</div>';
  }

  // Master column: only master names. A new name is added in the master sheet, not here.
  if (master && typed !== "" && !exactMatch) {
    html += '<div class="cell-hint">Name missing? Add it to the <b>' + escapeText(master.sheet)
          + '</b> sheet in Excel, run extract_excel.py, then refresh.</div>';
  }

  // Typed something that is not in the list -> offer it as a new value (numbers only in number columns)
  if (!master && typed !== "" && !exactMatch) {
    const okNumber = !isNumberColumn(col) || !isNaN(Number(typed));
    if (okNumber) {
      editChoices.push({ value: typed });
      html += '<div class="cell-option new-value"><span>+ Use &ldquo;<b>' + escapeText(typed) + '</b>&rdquo; as a new value</span></div>';
    } else if (editChoices.length === 0) {
      html += '<div class="cell-none">Please type a number</div>';
    }
  }

  if (html === "") {
    html = '<div class="cell-none">No values yet - type one</div>';
  }

  document.getElementById("cell-options").innerHTML = html;

  // Click on a line = pick it.  "mousedown" comes before the text box loses focus.
  const lines = document.querySelectorAll("#cell-options .cell-option");
  lines.forEach(function (line, index) {
    line.onmousedown = function (event) {
      event.preventDefault();
      editPick = index;
      pickHighlighted();
    };
  });

  highlightLine();
  placeCellList();
}

// Puts the list just under the cell (or above it when there is no room below)
function placeCellList() {
  const list = document.getElementById("cell-list");
  const place = editCell.getBoundingClientRect();
  list.hidden = false;
  if (isMultiColumn(editCell.dataset.col)) {
    list.style.width = Math.min(Math.max(place.width, 280), 340) + "px";   // tick list: a bit wider
  } else {
    list.style.width = Math.min(Math.max(place.width, 190), 260) + "px";
  }

  let left = place.left;
  if (left + list.offsetWidth > window.innerWidth - 8) {
    left = window.innerWidth - 8 - list.offsetWidth;
  }
  list.style.left = left + "px";

  const below = window.innerHeight - place.bottom - 12;
  if (below >= list.offsetHeight || below >= place.top) {
    list.style.top = (place.bottom + 2) + "px";
    list.style.maxHeight = below + "px";
  } else {
    list.style.top = Math.max(8, place.top - 2 - list.offsetHeight) + "px";
    list.style.maxHeight = (place.top - 12) + "px";
  }
}

// Arrow keys move the blue line up and down
function moveHighlight(step) {
  if (editChoices.length === 0) return;
  editPick = (editPick + step + editChoices.length) % editChoices.length;
  highlightLine();
}

function highlightLine() {
  const lines = document.querySelectorAll("#cell-options .cell-option");
  lines.forEach(function (line, index) {
    line.classList.toggle("active", index === editPick);
    if (index === editPick) {
      line.scrollIntoView({ block: "nearest" });
    }
  });
}

// Enter (or a click) puts the highlighted value in the cell
function pickHighlighted() {
  if (editChoices.length === 0) {
    return;
  }
  finishEdit(editCell, editChoices[editPick].value);
}

// Esc or clicking somewhere else: keep the value the cell had
function cancelEdit() {
  if (editCell) {
    finishEdit(editCell, editCell.dataset.value);
  }
}

// Shows the typed letters in yellow:  "Procurement" + "proc" -> "<u>Proc</u>urement"
function markText(text, typed) {
  if (typed === "") {
    return escapeText(text);
  }
  const start = text.toLowerCase().indexOf(typed.toLowerCase());
  if (start < 0) {
    return escapeText(text);
  }
  return escapeText(text.slice(0, start))
       + "<u>" + escapeText(text.slice(start, start + typed.length)) + "</u>"
       + escapeText(text.slice(start + typed.length));
}

// Puts the new value in the cell and remembers the change
function finishEdit(cell, newValue) {
  if (!cell.classList.contains("editing")) {
    return;
  }
  cell.classList.remove("editing");
  editCell = null;
  editInput = null;
  closeCellList();

  newValue = String(newValue).trim();
  cell.dataset.value = newValue;
  cell.title = newValue;

  const row = cell.parentElement;
  const col = cell.dataset.col;
  const key = row.dataset.id + "_" + col;
  const oldValue = cell.dataset.original;

  // Many names: "Charan,Jeet" and "Charan, Jeet" are the same -> keep the Excel text
  if (isMultiColumn(col) && splitNames(newValue).join(", ") === splitNames(oldValue).join(", ")) {
    newValue = oldValue;
    cell.dataset.value = newValue;
    cell.title = newValue;
  }

  // Did it really change? (numbers: 30 and 30.0 are the same)
  let changed = (newValue !== oldValue);
  if (isNumberColumn(col)) {
    changed = (Number(newValue || 0) !== Number(oldValue || 0));
  }

  if (changed) {
    changes[key] = {
      id: row.dataset.id,
      col: col,
      row: row.querySelector(".row-number").textContent,
      oldValue: oldValue,
      newValue: newValue,
    };
  } else {
    delete changes[key];
  }

  showCellValue(cell, changed ? oldValue : null);
  markMaster(cell);

  // Development or Functional changed -> Total Effort = Development + Functional (like the Excel formula)
  if (col == FORMULA_COLUMNS.dev || col == FORMULA_COLUMNS.func) {
    updateTotal(row);
  }
  updateSaveBar();
}

// Shows the value in the cell. A changed cell is yellow and shows the old value.
function showCellValue(cell, oldValue) {
  cell.classList.toggle("changed", oldValue !== null);

  // Not changed: put back exactly what the Excel showed (badges too)
  if (oldValue === null) {
    cell.innerHTML = cell.originalHtml;
    return;
  }

  const value = cell.dataset.value;
  let html = '<div class="cell-box"><span class="cell-text">';
  html += (value === "") ? '<span class="empty">—</span>' : escapeText(value);
  html += '<i class="was">was ' + escapeText(oldValue === "" ? "blank" : oldValue) + '</i></span>';
  html += '<svg class="cell-arrow" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></div>';
  cell.innerHTML = html;
}

// Hides the list under the cell (and the parts only the tick list uses)
function closeCellList() {
  document.getElementById("cell-list").hidden = true;
  document.getElementById("tick-search").hidden = true;
  document.getElementById("cell-head").hidden = true;
  document.getElementById("cell-foot").hidden = true;
}


// ---------- Tick list: several names in one cell (stakeholders list, business group) ----------

// Click on the cell -> the cell keeps its text, a tick list opens under it
function startTickEdit(cell) {
  const col = cell.dataset.col;
  editCell = cell;
  cell.classList.add("editing");
  const arrow = cell.querySelector(".cell-arrow");
  if (arrow) {
    arrow.classList.add("up");
  }

  // The names in the cell now are ticked, and come first. Then the other master names, A to Z.
  tickedNames = splitNames(cell.dataset.value);
  tickOrder = tickedNames.slice();
  for (const name of MASTERS[col].names) {
    if (!isTicked(name)) {
      tickOrder.push(name);
    }
  }

  const search = document.getElementById("tick-search");
  search.hidden = false;
  search.value = "";
  search.placeholder = "Search " + COLUMNS[col].name + "…";
  document.getElementById("cell-head").hidden = false;
  document.getElementById("cell-foot").hidden = false;

  editPick = 0;
  showTickList();
  search.focus();
}

function isTicked(name) {
  return tickedNames.some(function (ticked) { return ticked.toLowerCase() === name.toLowerCase(); });
}

// Builds the tick list (only the names that contain what you typed in the search box)
function showTickList() {
  const col = editCell.dataset.col;
  const typed = document.getElementById("tick-search").value.trim();
  const lowerTyped = typed.toLowerCase();

  editChoices = [];
  let html = "";
  for (const name of tickOrder) {
    if (lowerTyped !== "" && !name.toLowerCase().includes(lowerTyped)) {
      continue;
    }
    const on = isTicked(name);
    editChoices.push({ value: name });
    html += '<div class="cell-option tick-option' + (on ? " on" : "") + '">'
          + '<i>' + (on ? "&#10003;" : "") + '</i>'
          + '<span>' + markText(name, typed) + '</span>'
          + (inMaster(col, name) ? "" : '<em class="nm-tag">not in master</em>')
          + '</div>';
  }
  if (html === "") {
    html = '<div class="cell-hint">No match. Add the name to the <b>' + escapeText(MASTERS[col].sheet)
         + '</b> sheet in Excel, run extract_excel.py, then refresh.</div>';
  }
  document.getElementById("cell-options").innerHTML = html;
  if (editPick >= editChoices.length) {
    editPick = 0;
  }

  // Click a line = tick / untick it
  const lines = document.querySelectorAll("#cell-options .cell-option");
  lines.forEach(function (line, index) {
    line.onmousedown = function (event) {
      event.preventDefault();
      editPick = index;
      toggleHighlighted();
    };
  });

  document.getElementById("cell-head").innerHTML =
    '<span>From master <b>' + escapeText(MASTERS[col].sheet) + '</b></span><span>' + tickedNames.length + ' ticked</span>';
  document.getElementById("will-save").textContent = tickedNames.length > 0 ? tickedNames.join(", ") : "blank";

  highlightLine();
  placeCellList();
}

// Ticks or unticks the highlighted name
function toggleHighlighted() {
  if (editChoices.length === 0) {
    return;
  }
  const name = editChoices[editPick].value;
  if (isTicked(name)) {
    tickedNames = tickedNames.filter(function (ticked) { return ticked.toLowerCase() !== name.toLowerCase(); });
  } else {
    tickedNames.push(name);
  }
  showTickList();
}

// Clear: untick everything (the cell becomes blank when you press Done)
function clearTicks() {
  tickedNames = [];
  showTickList();
}

// Done: put the ticked names in the cell, e.g. "Charan, Jeet"
function finishTicks() {
  if (editCell) {
    finishEdit(editCell, tickedNames.join(", "));
  }
}


// Recalculates the Total Effort cell of one row
function updateTotal(row) {
  const devCell = getCell(row, FORMULA_COLUMNS.dev);
  const funcCell = getCell(row, FORMULA_COLUMNS.func);
  const totalCell = getCell(row, FORMULA_COLUMNS.total);
  if (!devCell || !funcCell || !totalCell) {
    return;
  }
  const total = Number(devCell.dataset.value || 0) + Number(funcCell.dataset.value || 0);
  totalCell.dataset.value = String(total);
  totalCell.querySelector(".cell-text").textContent = total;
}


// ============================================================
// 3. Save bar
// ============================================================

// Shows how many cells changed, and puts one hidden box per change in the form
function updateSaveBar() {
  const list = Object.values(changes);
  const form = document.getElementById("save-form");
  form.hidden = (list.length === 0);

  document.getElementById("change-count").textContent =
    list.length + (list.length === 1 ? " unsaved change" : " unsaved changes");

  // A short summary:  "Row 6: Development 30 → 35 · Row 8: Business Confirmation"
  const parts = [];
  for (const change of list) {
    let text = "Row " + change.row + ": " + COLUMNS[change.col].name;
    if (isNumberColumn(change.col)) {
      text += " " + (change.oldValue || 0) + " → " + (change.newValue || 0);
    }
    parts.push(text);
  }
  document.getElementById("change-list").textContent = parts.join(" · ");

  // The boxes Python reads:  cell_<id>_<column number>
  const boxes = document.getElementById("save-boxes");
  boxes.innerHTML = "";
  for (const change of list) {
    const box = document.createElement("input");
    box.type = "hidden";
    box.name = "cell_" + change.id + "_" + change.col;
    box.value = change.newValue;
    boxes.appendChild(box);
  }
}

// Discard: load the page again (nothing was saved yet)
function discardChanges() {
  changes = {};
  location.reload();
}


// ============================================================
// 4. Columns menu: tick = show the column, untick = hide it
// ============================================================

// The columns that the Excel file shows (the start view)
function getExcelColumns() {
  const list = [];
  for (const col in COLUMNS) {
    if (COLUMNS[col].inExcel) {
      list.push(col);
    }
  }
  return list;
}

// Hides and shows the columns, and gives the table its width
function showColumns() {
  // 1. Every header cell and every cell gets the class "column-hidden" or not
  for (const cell of document.querySelectorAll("#sheet [data-col]")) {
    cell.classList.toggle("column-hidden", !shownColumns.includes(cell.dataset.col));
  }

  // 2. The <colgroup> (column widths) only has the shown columns
  let html = '<col style="width: 38px">';
  let width = 38;
  for (const col in COLUMNS) {
    if (shownColumns.includes(col)) {
      html += '<col style="width: ' + COLUMNS[col].width + 'px">';
      width = width + COLUMNS[col].width;
    }
  }
  document.getElementById("sheet-cols").innerHTML = html;
  document.getElementById("sheet").style.width = width + "px";

  // 3. The button shows "21 / 37"
  document.getElementById("columns-count").textContent = shownColumns.length + " / " + Object.keys(COLUMNS).length;

  // 4. Remember the choice for one year in a cookie, e.g. "0-1-2-5" (Python reads it next time)
  document.cookie = "mbbp_columns=" + shownColumns.join("-") + "; max-age=31536000; path=/";
}

// Opens the menu with a tick for every shown column
function openColumnsMenu() {
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = shownColumns.includes(box.value);
    box.parentElement.hidden = false;
  }
  document.getElementById("columns-find").value = "";
  countTickedColumns();

  const menu = document.getElementById("columns-menu");
  const place = document.getElementById("columns-button").getBoundingClientRect();
  menu.hidden = false;
  menu.style.top = (place.bottom + 6) + "px";
  menu.style.left = Math.max(8, place.right - menu.offsetWidth) + "px";
  menu.style.maxHeight = (window.innerHeight - place.bottom - 16) + "px";
}

function closeColumnsMenu() {
  document.getElementById("columns-menu").hidden = true;
}

// "21 of 37 shown", and the Select all box: ✓, – or empty
function countTickedColumns() {
  const boxes = Array.from(document.querySelectorAll(".column-box"));
  const ticked = boxes.filter(function (box) { return box.checked; }).length;
  document.getElementById("columns-ticked").textContent = ticked;
  const selectAll = document.getElementById("columns-select-all");
  selectAll.checked = (ticked === boxes.length);
  selectAll.indeterminate = (ticked > 0 && ticked < boxes.length);
}

function tickAllColumns(checked) {
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = checked;
  }
  countTickedColumns();
}

// "Excel default": tick only the columns the Excel file shows
function tickExcelColumns() {
  const excel = getExcelColumns();
  for (const box of document.querySelectorAll(".column-box")) {
    box.checked = excel.includes(box.value);
  }
  countTickedColumns();
}

// The search box in the menu hides column names that don't match
function findColumn() {
  const text = document.getElementById("columns-find").value.toLowerCase();
  for (const box of document.querySelectorAll(".column-box")) {
    box.parentElement.hidden = !box.parentElement.textContent.toLowerCase().includes(text);
  }
}

// Apply: show the ticked columns
function applyColumns() {
  const ticked = [];
  for (const box of document.querySelectorAll(".column-box")) {
    if (box.checked) {
      ticked.push(box.value);
    }
  }
  if (ticked.length === 0) {
    alert("Please tick at least one column.");
    return;
  }
  shownColumns = ticked;
  closeColumnsMenu();
  showColumns();
}


// ============================================================
// Connect the functions to clicks and typing
// ============================================================

// Click a filter icon -> open its menu.  Click outside a menu -> close it.
document.addEventListener("click", function (event) {
  const button = event.target.closest(".filter-button");
  if (button) {
    closeColumnsMenu();
    openFilterMenu(button);
    return;
  }
  if (event.target.closest("#columns-button")) {
    closeFilterMenu();
    if (document.getElementById("columns-menu").hidden) {
      openColumnsMenu();
    } else {
      closeColumnsMenu();
    }
    return;
  }
  if (!event.target.closest("#filter-menu")) {
    closeFilterMenu();
  }
  if (!event.target.closest("#columns-menu")) {
    closeColumnsMenu();
  }
});

// Click an editable cell -> edit it
document.querySelector("#sheet tbody").addEventListener("click", function (event) {
  const cell = event.target.closest("td.editable");
  if (cell) {
    startEdit(cell);
  }
});

// Tick list search box: type to find a name, arrows move, Enter ticks, Esc cancels.
// Clicking somewhere else (the box loses focus) = Cancel.
const tickSearch = document.getElementById("tick-search");
tickSearch.addEventListener("input", function () {
  editPick = 0;
  showTickList();
});
tickSearch.addEventListener("keydown", function (event) {
  if (event.key === "ArrowDown") { moveHighlight(1); event.preventDefault(); }
  if (event.key === "ArrowUp") { moveHighlight(-1); event.preventDefault(); }
  if (event.key === "Enter") { toggleHighlighted(); event.preventDefault(); }
  if (event.key === "Escape") { cancelEdit(); }
});
tickSearch.addEventListener("blur", function () {
  cancelEdit();
});

// A click inside the list must not take the focus away from the search box / the cell
document.getElementById("cell-list").addEventListener("mousedown", function (event) {
  if (event.target.id !== "tick-search") {
    event.preventDefault();
  }
});

// Scrolling the table moves the cell away from its list -> stop editing
document.querySelector(".sheet-box").addEventListener("scroll", function () {
  cancelEdit();
});

// Type in "Search" -> filter the rows
document.getElementById("table-search").addEventListener("input", function (event) {
  searchText = event.target.value.toLowerCase().trim();
  applyAllFilters();
});

// Saving: no warning.  Leaving the page with unsaved changes: ask first.
let saving = false;
document.getElementById("save-form").addEventListener("submit", function () {
  saving = true;
});
window.addEventListener("beforeunload", function (event) {
  if (!saving && Object.keys(changes).length > 0) {
    event.preventDefault();
    event.returnValue = "";
  }
});

// Start: mark the values that are not in the master sheets (orange)
for (const col in MASTERS) {
  for (const cell of document.querySelectorAll('#sheet tbody td[data-col="' + col + '"]')) {
    markMaster(cell);
  }
}

// Start: Python already hid the columns you unticked last time. Just remember which ones are shown.
for (const col in COLUMNS) {
  if (COLUMNS[col].shown) {
    shownColumns.push(col);
  }
}
document.getElementById("columns-count").textContent = shownColumns.length + " / " + Object.keys(COLUMNS).length;
