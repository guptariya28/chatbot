import truststore
truststore.inject_into_ssl()  # use the Windows certificate store (corporate CA)

import os
import requests
import pandas as pd
from flask import Flask, redirect, session, render_template
from auth import auth  # the login routes live in auth.py

CLOUD_ID = "5eaafa7e-0030-48e0-8f55-59054d26628e"
SITE = "https://mercedes-benz-pace.atlassian.net"

PROJECTS = ["FPM", "SAC", "TAFM"]
JQL = f"project in ({', '.join(PROJECTS)}) ORDER BY created DESC"
FIELDS = "summary,issuetype,status,priority,reporter,assignee,created,updated,duedate,project"

app = Flask(__name__)
app.secret_key = os.environ["FLASK_SECRET_KEY"]
app.register_blueprint(auth)


@app.route("/")
def issues():
    if "token" not in session:
        return redirect("/login")

    url = f"https://api.atlassian.com/ex/jira/{CLOUD_ID}/rest/api/3/search/jql"
    headers = {"Authorization": f"Bearer {session['token']}", "Accept": "application/json"}
    params = {"jql": JQL, "fields": FIELDS, "maxResults": 100}

    rows = []
    while True:
        r = requests.get(url, headers=headers, params=params)
        if r.status_code == 401:  # token expired (after ~1 hour) -> log in again
            session.clear()
            return redirect("/login")
        r.raise_for_status()
        data = r.json()

        for issue in data["issues"]:
            f = issue["fields"]
            rows.append({
                "Key": issue["key"],
                "Summary": f["summary"],
                "Type": f["issuetype"]["name"],
                "Status": f["status"]["name"],
                "Priority": (f["priority"] or {}).get("name", ""),
                "Project": f["project"]["key"],
                "Reporter": (f["reporter"] or {}).get("displayName", ""),
                "Assignee": (f["assignee"] or {}).get("displayName", "Unassigned"),
                "Created": f["created"][:10],
                "Updated": f["updated"][:10],
                "Due date": f["duedate"] or "",
                "Link": f"{SITE}/browse/{issue['key']}",
            })

        if data.get("isLast", True):
            break
        params["nextPageToken"] = data["nextPageToken"]

    df = pd.DataFrame(rows)
    table = df.to_html(index=False, border=0, render_links=True, table_id="issues")
    return render_template("index.html", table=table, count=len(df))


if __name__ == "__main__":
    app.run(port=5000, debug=True)
