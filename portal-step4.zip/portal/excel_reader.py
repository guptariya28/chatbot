# excel_reader.py
# STEP 1: Read the demand list and the master lists from Excel and give them to the portal.
# It reads the SMALL file portal_data.xlsx (made by:  python extract_excel.py),
# not the big MBBP26_Apr_V1.xlsx, because the big one is slow to open.
# This file only READS the Excel. It never changes it.

import os
import warnings
import pandas as pd
from openpyxl import load_workbook

# Hide the harmless "Data Validation" warning from openpyxl
warnings.filterwarnings("ignore")

HERE = os.path.dirname(os.path.abspath(__file__))       # the portal folder
EXCEL_FILE = os.path.join(HERE, "portal_data.xlsx")     # made by extract_excel.py
SHEET_NAME = "MBBP_2026_09Apr"
HEADER_ROW = 3          # column names are in Excel row 4 (pandas counts from 0)


# Register column -> master sheet (tab name). Names: column A, from row 2 down (row 1 is the header).
MASTER_SHEETS = {
    "IO Lead": "IO Leads",
    "Reporter": "Reporter",
    "Customer_L5(Reporter)": "Customer l4",
    "Module.1": "Module",                  # the 2nd "Module" column (FICO, ABAP ...). pandas calls it "Module.1"
    "stakeholders list": "Stakeholders_list",
    "business group": "business group",
}

# These columns can hold more than one name in a cell, separated by commas: "Charan, Jeet"
MULTI_NAME_COLUMNS = ["stakeholders list", "business group"]


# Stops with a clear message when the small file was not made yet
def check_file():
    if not os.path.exists(EXCEL_FILE):
        raise SystemExit("portal_data.xlsx not found. Run this first:  python extract_excel.py")


def load_demands():
    check_file()
    # 1. Read the sheet
    data = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, header=HEADER_ROW)

    # 2. Keep only real items (rows that have an SI NO)
    # The Excel row number of every line (pandas line 0 = Excel row 5, because the headers are in row 4)
    data.insert(0, "excel_row", data.index + HEADER_ROW + 2)

    data = data[data["SI NO"].notna()]

    # 3. Show SI NO as 1, 2, 3 instead of 1.0, 2.0, 3.0
    data["SI NO"] = data["SI NO"].astype(int)

    # 4. Add our own unique id (SI NO repeats, so we can't use it)
    data.insert(0, "id", range(1, len(data) + 1))

    # 5. Empty cells: NaN -> "" (empty text)
    data = data.fillna("")

    # 6. Turn the table into a list of rows
    rows = data.to_dict(orient="records")

    return rows


# Which columns are VISIBLE in the Excel (not hidden, not folded with "+").
# Returns the column names in Excel order, e.g. ["SI NO", "SAP STACK /AI/ 3rd Party tool", ...]
def get_visible_columns():
    # 1. The column names (nrows=0 -> read only the header, no data)
    header = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, header=HEADER_ROW, nrows=0)
    names = list(header.columns)

    # 2. Ask openpyxl which Excel columns are hidden.
    #    A "dimension" describes one column or a range of columns (min to max),
    #    e.g. columns 5 to 10 (E to J) folded together.
    workbook = load_workbook(EXCEL_FILE)
    sheet = workbook[SHEET_NAME]

    hidden_numbers = []
    for dimension in sheet.column_dimensions.values():
        if dimension.hidden and dimension.min:
            for number in range(dimension.min, dimension.max + 1):
                hidden_numbers.append(number)

    # 3. Keep the names whose Excel column is not hidden.
    #    names[0] is Excel column 1 (A), names[1] is column 2 (B), ...
    visible = []
    for position in range(len(names)):
        excel_number = position + 1
        if excel_number not in hidden_numbers:
            visible.append(names[position])

    return visible


# Reads the 6 master lists.
# Returns  { "IO Lead": ["Dheeraj K", "Durga", ...], "Reporter": [...], ... }
# Every name once (Ravi S twice in the sheet -> once), spaces trimmed, A to Z.
# A master sheet that is missing is left out -> that column keeps its old dropdown.
def load_masters():
    check_file()
    workbook = load_workbook(EXCEL_FILE, read_only=True, data_only=True)

    masters = {}
    for column, sheet_name in MASTER_SHEETS.items():
        # find the tab (small/capital letters don't matter)
        sheet = None
        for name in workbook.sheetnames:
            if name.strip().lower() == sheet_name.lower():
                sheet = workbook[name]
        if sheet is None:
            continue

        names = []
        seen = []
        for row in sheet.iter_rows(min_row=2, max_col=1, values_only=True):
            # " ".join(text.split()) -> removes extra spaces, also hidden ones copied from email/web
            name = " ".join(str(row[0] or "").split())
            if name == "" or name.lower() in seen:
                continue
            seen.append(name.lower())
            names.append(name)
        names.sort(key=str.lower)
        masters[column] = names

    workbook.close()
    return masters


# When was portal_data.xlsx last saved? (a number; it changes every time you run extract_excel.py)
def file_time():
    return os.path.getmtime(EXCEL_FILE)


# ------------------------------------------------------------
# Runs ONLY when you run this file directly:  python excel_reader.py
# ------------------------------------------------------------
if __name__ == "__main__":
    demands = load_demands()
    print("Items loaded:", len(demands))
    print("Columns per item:", len(demands[0]))

    print()
    print("Columns visible in Excel:")
    for name in get_visible_columns():
        print("  ", name)

    print()
    print("Master lists:")
    for column, names in load_masters().items():
        print("  ", column, "->", len(names), "names")
