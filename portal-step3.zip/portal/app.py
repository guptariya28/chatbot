# app.py
# The website. Every page is one function ("route").
# The math is in calculations.py, reading Excel is in excel_reader.py.

import io
from datetime import datetime
from urllib.parse import urlencode

import pandas as pd
from flask import Flask, Request, render_template, request, redirect, url_for, session, send_file

from excel_reader import load_demands, get_visible_columns
import calculations as calc


# The editable table sends many boxes at once (rows x columns).
# Flask's normal limit is 1000 boxes, so we allow more.
class BigFormRequest(Request):
    max_form_parts = 100000
    max_form_memory_size = 50 * 1024 * 1024


app = Flask(__name__)
app.request_class = BigFormRequest
app.secret_key = "change-this-later"   # needed to remember "Viewing as" (the session)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0   # browser always loads the newest style.css
app.config["TEMPLATES_AUTO_RELOAD"] = True      # HTML changes show without restarting


# ============================================================
# Data in memory (read once when the app starts)
# Edits stay only while the app runs. Use "Download Excel" to keep them.
# ============================================================
demands = load_demands()
change_log = []
settings = calc.make_default_settings(demands)

# All Excel columns (without our own "id" and "excel_row"), in Excel order
ALL_COLUMNS = []
for column_name in demands[0]:
    if column_name != "id" and column_name != "excel_row":
        ALL_COLUMNS.append(column_name)

# Only the columns that are visible in the Excel (not hidden)
VISIBLE_COLUMNS = get_visible_columns()

# Columns nobody can type into: SI NO, and the ones the Excel calculates
READ_ONLY_COLUMNS = [
    calc.SI_NO_COLUMN,
    calc.EFFORT_COLUMN,
    "Total Effort (Man-Days).1",
    calc.PACKAGE_COLUMN,
]

# The Functional Effort column has a line break in its name, so we find it
FUNC_COLUMN = calc.find_column(demands[0], "Funtional Effort")

# The months the plan covers (shown on the FTE needed card)
PLAN_PERIOD = "Apr–Dec"

ROLES = [
    {"value": "admin", "label": "PMO Admin"},
    {"value": "io_lead", "label": "IO Lead"},
    {"value": "business", "label": "Business User"},
    {"value": "viewer", "label": "Viewer"},
]


# ============================================================
# Who is using the portal? (no login yet - picked in the top bar)
# ============================================================
def get_current_user():
    role = session.get("role", "admin")
    name = session.get("name", "PMO Admin")
    return {"role": role, "name": name}


# admin -> can edit everything.  IO Lead -> only items where they are the IO Lead.
def can_edit(user, row):
    if user["role"] == "admin":
        return True
    if user["role"] == "io_lead" and calc.same_text(row.get(calc.IO_LEAD_COLUMN, ""), user["name"]):
        return True
    return False


def can_raise_request(user):
    return user["role"] == "admin" or user["role"] == "business"


def find_demand(demand_id):
    for row in demands:
        if row["id"] == demand_id:
            return row
    return None


def add_log(user, row, text):
    entry = {
        "time": datetime.now().strftime("%d %b %Y, %H:%M"),
        "user": user["name"],
        "item": row,
        "text": text,
    }
    change_log.insert(0, entry)   # newest first


def count_pending_requests():
    count = 0
    for row in demands:
        if row.get(calc.REQUEST_STATUS_COLUMN, "") == "Pending review":
            count = count + 1
    return count


# The same Excel formulas, run again after an edit:
#   Total Effort = Development + Functional
#   IS PACKAGE   = 1 if "MS/MT PKG", else 0
def update_formulas(row, effort_changed):
    if effort_changed:
        row[calc.EFFORT_COLUMN] = calc.to_number(row[calc.DEV_COLUMN]) + calc.to_number(row[FUNC_COLUMN])
    if calc.is_package(row):
        row[calc.PACKAGE_COLUMN] = 1
    else:
        row[calc.PACKAGE_COLUMN] = 0


# The current web address with one value changed.
# Used for the buttons "All columns", "Edit table" ... so the filters stay.
def make_url(page, key, value):
    params = {}
    for name in request.args:
        params[name] = request.args.get(name)
    if value == "":
        params.pop(key, None)        # remove it from the address
    else:
        params[key] = value
    params.pop("saved", None)
    return page + "?" + urlencode(params)


# Builds one chart card.
# chart_type: "bars", "columns", "pie" or "donut"
# color: one color for all bars (e.g. "#E66C37"), or "" for a different color per group
def make_card(card_id, title, rows, column, measure, filter_name, chart_type, color=""):
    per_fte = settings["man_days_per_fte"]
    groups = calc.group_rows(rows, column, per_fte, measure)
    return finish_card(card_id, title, groups, filter_name, chart_type, color)


# The delivery timeline card: groups by month or by quarter (?period=quarter)
def make_delivery_card(rows, period):
    per_fte = settings["man_days_per_fte"]
    groups = calc.group_by_delivery(rows, per_fte, period)
    card = finish_card("delivery", "Delivery timeline (items)", groups, "", "columns", "#118DFF")

    card["period"] = period
    card["month_url"] = make_url("/", "period", "")
    card["quarter_url"] = make_url("/", "period", "quarter")
    return card


# The part that is the same for every card: links, one color, totals, pie colors
def finish_card(card_id, title, groups, filter_name, chart_type, color):
    per_fte = settings["man_days_per_fte"]

    if color != "":
        for group in groups:
            group["color"] = color

    # Clicking a name opens the Register filtered on that value
    for group in groups:
        group["link"] = ""
        if filter_name != "" and group["label"] != "(blank)":
            group["link"] = "/register?" + urlencode({filter_name: group["label"]})

    card = {
        "id": card_id,
        "title": title,
        "chart_type": chart_type,
        "groups": groups,
        "totals": calc.get_totals(groups, per_fte),
        "pie_style": calc.make_pie_style(groups),
    }
    # The number in the middle of a donut (all items, unless changed later)
    card["center_value"] = card["totals"]["count"]
    card["center_label"] = "items"
    return card


# Shows 50.0 as 50 (whole numbers without ".0").  Use in HTML:  {{ value|nice }}
@app.template_filter("nice")
def nice_number(value):
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


# Shows a column name like Excel does: "Module.1" -> "Module"
# and removes the line break inside "Funtional Effort \n(Man-Days)"
@app.template_filter("excel_name")
def excel_name(column):
    if column.endswith(".1"):
        column = column[:-2]
    return column.replace("\n", " ")


# These values are available in EVERY page (the top bar needs them)
@app.context_processor
def add_common_values():
    return {
        "user": get_current_user(),
        "roles": ROLES,
        "io_lead_names": calc.get_unique_values(demands, calc.IO_LEAD_COLUMN),
        "pending_count": count_pending_requests(),
    }


# ============================================================
# The whole portal is ONE page ("/") and ONE html file (templates/index.html).
# Every tab (Overview, Demand register, ...) gets its numbers from its own function below
# (they return a dict), and the page shows one tab at a time. Clicking a tab only switches what is shown,
# so nothing reloads or jumps. The address shows the tab:  /#register
# ============================================================
@app.route("/")
def home():
    return render_template(
        "index.html",
        overview=dashboard_part(),
        register=register_part(),
        summary=summary_part(),
        requests=requests_part(),
        new_request=new_request_part(),
        log=log_part(),
    )


# Old addresses (e.g. /register) still work: they open the one page on that tab
def go_to_tab(tab):
    query = request.query_string.decode()
    if query != "":
        return redirect("/?" + query + "#" + tab)
    return redirect("/#" + tab)


# ============================================================
# Tab 1: Overview (dashboard)
# ============================================================
def dashboard_part():
    chosen = calc.read_filters(request.args)
    rows = calc.apply_filters(demands, chosen)
    per_fte = settings["man_days_per_fte"]

    # KPI cards
    total_man_days = 0
    must_count = 0
    package_count = 0
    non_aop_count = 0
    for row in rows:
        total_man_days = total_man_days + calc.get_effort(row)
        if calc.is_must_have(row):
            must_count = must_count + 1
        if calc.is_package(row):
            package_count = package_count + 1
        if calc.same_text(row.get(calc.AOP_COLUMN, ""), "NON-AOP"):
            non_aop_count = non_aop_count + 1

    item_count = len(rows)
    aop_count = item_count - non_aop_count

    # Percentages (only when there are items, so we never divide by 0)
    must_percent = 0
    package_percent = 0
    aop_percent = 0
    if item_count > 0:
        must_percent = round(must_count / item_count * 100)
        package_percent = round(package_count / item_count * 100)
        aop_percent = round(aop_count / item_count * 100)

    kpis = {
        "item_count": item_count,
        "aop": aop_count,
        "non_aop": non_aop_count,
        "aop_percent": aop_percent,
        "man_days": total_man_days,
        "fte": round(total_man_days / per_fte, 2),
        "per_fte": per_fte,
        "must": must_count,
        "must_percent": must_percent,
        "packages": package_count,
        "package_percent": package_percent,
        "plan_period": PLAN_PERIOD,
    }

    # Delivery timeline: by month (default) or by quarter
    period = request.args.get("period", "month")

    # The chart cards (dashboard.html puts them in the grid)
    iolead_card = make_card("iolead", "Items by IO lead", rows, calc.IO_LEAD_COLUMN, "count", "io_lead", "bars", "#E66C37")
    e4_card = make_card("e4", "FTE by business E4 manager", rows, calc.E4_COLUMN, "fte", "e4_manager", "bars", "#12239E")
    confirmation_card = make_card("confirmation", "Business confirmation", rows, calc.CONFIRMATION_COLUMN, "count", "confirmation", "donut")
    mode_card = make_card("mode", "In-house vs MS/MT", rows, calc.MODE_COLUMN, "count", "", "donut")
    module_card = make_card("module", "Effort by tech module (man-days)", rows, calc.MODULE_COLUMN, "man_days", "tech_module", "bars", "#118DFF")
    delivery_card = make_delivery_card(rows, period)

    # Biggest tech module, for the Total effort card (the module card is sorted, biggest first)
    kpis["top_module"] = "-"
    kpis["top_module_percent"] = 0
    if len(module_card["groups"]) > 0:
        kpis["top_module"] = module_card["groups"][0]["label"]
        kpis["top_module_percent"] = round(module_card["groups"][0]["share"])

    # Smallest tech module (the last one in the sorted list, but not "(blank)")
    kpis["low_module"] = "-"
    kpis["low_module_percent"] = 0
    for group in module_card["groups"]:
        if group["label"] != "(blank)":
            kpis["low_module"] = group["label"]
            kpis["low_module_percent"] = round(group["share"])

    # The In-house vs MS/MT donut shows the MS/MT count in the middle
    mode_card["center_value"] = package_count
    mode_card["center_label"] = "MS/MT"

    return dict(chosen=chosen,
        filters=calc.FILTERS,
        filter_options=calc.get_filter_options(demands),
        kpis=kpis,
        iolead_card=iolead_card,
        e4_card=e4_card,
        confirmation_card=confirmation_card,
        mode_card=mode_card,
        module_card=module_card,
        delivery_card=delivery_card,
        period=period,
    )


# ============================================================
# Tab 2: Demand Register (an Excel-like table)
#   Click a cell to edit it (type to search the list), the filter icon in a header to filter / sort,
#   "Columns" to show or hide columns. That part is in static/register.js
# ============================================================

# Column number -> Excel letter:  0 -> "A",  25 -> "Z",  26 -> "AA"
def column_letter(number):
    letters = ""
    number = number + 1
    while number > 0:
        number, rest = divmod(number - 1, 26)
        letters = chr(65 + rest) + letters
    return letters


@app.route("/register")
def register():
    return go_to_tab("register")


def register_part():
    rows = demands
    user = get_current_user()

    # Every column is sent to the page. The "Columns" menu (register.js) hides the ones you untick.
    # Your last choice is kept in a cookie, e.g. "0-1-2-5". No cookie = the columns visible in the Excel file.
    # Python already hides the other columns, so the table does not jump while the page opens.
    chosen_numbers = []
    for part in request.cookies.get("mbbp_columns", "").split("-"):
        if part.isdigit() and int(part) < len(ALL_COLUMNS):
            chosen_numbers.append(int(part))

    columns = []
    table_width = 38                               # the row-number column on the left
    for column in ALL_COLUMNS:
        number = ALL_COLUMNS.index(column)

        # Fixed column width (like Excel). Long text gets "..." - hover a cell to see all of it.
        if column == calc.SI_NO_COLUMN:
            width = 80
        elif column == calc.REQUIREMENT_COLUMN or column == "Comments":
            width = 300
        elif calc.is_number_column(column):
            width = 120
        else:
            width = 160

        if len(chosen_numbers) > 0:
            shown = number in chosen_numbers
        else:
            shown = column in VISIBLE_COLUMNS
        if shown:
            table_width = table_width + width

        columns.append({
            "width": width,
            "name": column,
            "number": number,                      # position, used in the save box name
            "letter": column_letter(number),       # A, B, C ... like Excel
            "in_excel": column in VISIBLE_COLUMNS, # False = hidden in the Excel file
            "shown": shown,                        # False = hidden with the Columns menu
            "editable": column not in READ_ONLY_COLUMNS,
            "is_formula": column in READ_ONLY_COLUMNS and column != calc.SI_NO_COLUMN,   # shows "ƒx"
            "is_number": calc.is_number_column(column),
            "is_wide": column == calc.REQUIREMENT_COLUMN or column == "Comments",
        })

    # Which rows can this user edit?
    editable_ids = []
    for row in rows:
        if can_edit(user, row):
            editable_ids.append(row["id"])

    # Column numbers the page needs to recalculate Total Effort while you type
    formula = {
        "dev": ALL_COLUMNS.index(calc.DEV_COLUMN),
        "func": ALL_COLUMNS.index(FUNC_COLUMN),
        "total": ALL_COLUMNS.index(calc.EFFORT_COLUMN),
    }

    return dict(rows=rows,
        total_count=len(demands),
        columns=columns,
        table_width=table_width,
        editable_ids=editable_ids,
        formula=formula,
        confirmation_column=calc.CONFIRMATION_COLUMN,
        aop_column=calc.AOP_COLUMN,
        mode_column=calc.MODE_COLUMN,
        saved=request.args.get("saved"),
        can_raise=can_raise_request(user),
    )


# Saves the editable table.
# Every input box is called  cell_<id>_<column number>,  e.g. "cell_12_5"
@app.route("/register/save", methods=["POST"])
def save_register():
    user = get_current_user()
    change_count = 0
    changed_rows = {}     # id -> True if effort changed in that row

    for box_name in request.form:
        if not box_name.startswith("cell_"):
            continue

        parts = box_name.split("_")          # "cell_12_5" -> ["cell", "12", "5"]
        demand_id = int(parts[1])
        column = ALL_COLUMNS[int(parts[2])]

        row = find_demand(demand_id)
        if row is None or not can_edit(user, row):
            continue
        if column in READ_ONLY_COLUMNS:
            continue

        old_value = row.get(column, "")
        new_value = request.form.get(box_name, "").strip()

        # Did it really change?
        if calc.is_number_column(column):
            if calc.to_number(old_value) == calc.to_number(new_value):
                continue
            if new_value != "":
                new_value = calc.to_number(new_value)
        else:
            if calc.clean_text(old_value) == new_value:
                continue

        # Save it and write the log
        row[column] = new_value
        add_log(user, row, excel_name(column) + ': "' + str(nice_number(old_value)) + '" -> "' + str(nice_number(new_value)) + '"')
        change_count = change_count + 1

        if demand_id not in changed_rows:
            changed_rows[demand_id] = False
        if calc.is_number_column(column):
            changed_rows[demand_id] = True

    # Run the Excel formulas again for the rows that changed
    for demand_id in changed_rows:
        update_formulas(find_demand(demand_id), changed_rows[demand_id])

    # Back to the table, showing how many cells were saved
    return redirect("/?saved=" + str(change_count) + "#register")


# ============================================================
# Tab 3: Raise a new Non-AOP request
# ============================================================
@app.route("/new-request", methods=["GET", "POST"])
def new_request():
    user = get_current_user()
    if request.method == "GET":
        return go_to_tab("new-request")
    if not can_raise_request(user):
        return "Only Business users or PMO can raise a request", 403

    if request.method == "POST":
        # A new row with every column empty
        new_row = {}
        for column in demands[0]:
            new_row[column] = ""

        biggest_id = 0
        for row in demands:
            if row["id"] > biggest_id:
                biggest_id = row["id"]

        new_row["id"] = biggest_id + 1
        new_row[calc.AOP_COLUMN] = "NON-AOP"
        new_row[calc.REQUEST_STATUS_COLUMN] = "Pending review"
        new_row[calc.REQUIREMENT_COLUMN] = request.form.get("requirement", "").strip()
        new_row[calc.TOPIC_COLUMN] = request.form.get("topic", "").strip()
        new_row[calc.MODULE_COLUMN] = request.form.get("module", "").strip()
        new_row[calc.IO_LEAD_COLUMN] = request.form.get("io_lead", "").strip()
        new_row[calc.E4_COLUMN] = request.form.get("e4_manager", "").strip()
        new_row[calc.CONFIRMATION_COLUMN] = request.form.get("confirmation", "").strip()
        new_row["Reporter"] = request.form.get("reporter", "").strip()
        new_row[calc.DELIVERY_COLUMN] = request.form.get("delivery", "").strip()
        new_row["Comments"] = request.form.get("comments", "").strip()
        new_row[calc.DEV_COLUMN] = calc.to_number(request.form.get("dev_days", ""))
        new_row[FUNC_COLUMN] = calc.to_number(request.form.get("func_days", ""))
        update_formulas(new_row, True)

        demands.append(new_row)
        add_log(user, new_row, "raised a new Non-AOP request")

        return redirect("/#requests")


# The "New Non-AOP request" form (a tab without a button in the top bar)
def new_request_part():
    user = get_current_user()
    options = {
        "topic": calc.get_unique_values(demands, calc.TOPIC_COLUMN),
        "module": calc.get_unique_values(demands, calc.MODULE_COLUMN),
        "io_lead": calc.get_unique_values(demands, calc.IO_LEAD_COLUMN),
        "e4_manager": calc.get_unique_values(demands, calc.E4_COLUMN),
        "confirmation": calc.get_unique_values(demands, calc.CONFIRMATION_COLUMN),
    }
    return dict(options=options, can_raise=can_raise_request(user))


# ============================================================
# Tab 4: Non-AOP requests (PMO approves or rejects)
# ============================================================
@app.route("/requests")
def requests_page():
    return go_to_tab("requests")


def requests_part():
    request_rows = []
    for row in demands:
        if row.get(calc.REQUEST_STATUS_COLUMN, "") != "":
            request_rows.append(row)

    user = get_current_user()
    return dict(rows=request_rows,
        can_raise=can_raise_request(user),
    )


@app.route("/approve/<int:demand_id>", methods=["POST"])
def approve(demand_id):
    user = get_current_user()
    row = find_demand(demand_id)
    if user["role"] == "admin" and row is not None:
        row[calc.REQUEST_STATUS_COLUMN] = "Approved"
        add_log(user, row, "approved the request")
    return redirect("/#requests")


@app.route("/reject/<int:demand_id>", methods=["POST"])
def reject(demand_id):
    user = get_current_user()
    row = find_demand(demand_id)
    if user["role"] == "admin" and row is not None:
        row[calc.REQUEST_STATUS_COLUMN] = "Rejected"
        add_log(user, row, "rejected the request")
    return redirect("/#requests")


# ============================================================
# Tab 5: FTE Summary (the MBBP_Summary sheet)
# ============================================================
@app.route("/summary")
def summary():
    return go_to_tab("summary")


def summary_part():
    result = calc.calculate_summary(demands, settings)

    cards = [
        make_card("sum-e4", "Required FTE by Business E4 Manager", result["scope_rows"], calc.E4_COLUMN, "fte", "e4_manager", "bars"),
        make_card("sum-pkg", "Packaging possible (MS/MT PKG) by E4 Manager", result["package_rows"], calc.E4_COLUMN, "fte", "e4_manager", "bars"),
        make_card("sum-module", "Required FTE by Tech Module", result["scope_rows"], calc.MODULE_COLUMN, "fte", "tech_module", "donut"),
    ]

    return dict(result=result,
        settings=settings,
        cards=cards,
    )


@app.route("/summary/settings", methods=["POST"])
def save_settings():
    user = get_current_user()
    if user["role"] != "admin":
        return "Only PMO can change the settings", 403

    per_fte = calc.to_number(request.form.get("man_days_per_fte", ""))
    if per_fte > 0:
        settings["man_days_per_fte"] = per_fte

    settings["available_man_days"] = calc.to_number(request.form.get("available_man_days", ""))
    settings["included_modules"] = request.form.getlist("modules")
    settings["included_deliveries"] = request.form.getlist("deliveries")

    return redirect("/#summary")


# ============================================================
# Tab 6: Change log
# ============================================================
@app.route("/log")
def log():
    return go_to_tab("log")


def log_part():
    return dict(change_log=change_log)


# ============================================================
# Top bar: "Viewing as"  and  "Download Excel"
# ============================================================
@app.route("/set-role", methods=["POST"])
def set_role():
    role = request.form.get("role", "admin")
    session["role"] = role

    if role == "admin":
        session["name"] = "PMO Admin"
    if role == "io_lead":
        session["name"] = request.form.get("io_lead_name", "")
    if role == "business":
        session["name"] = "Business User"
    if role == "viewer":
        session["name"] = "Viewer"

    # go back to the tab you were on (the top bar sends it in the box "tab")
    tab = request.form.get("tab", "overview")
    return redirect("/#" + tab)


@app.route("/download")
def download():
    table = pd.DataFrame(demands)
    table = table.drop(columns=["id", "excel_row"])   # our own helper columns, not in the Excel
    file = io.BytesIO()                       # a file in memory, not on disk
    table.to_excel(file, index=False, sheet_name="MBBP_2026_09Apr")
    file.seek(0)                              # go back to the start of the file
    return send_file(file, as_attachment=True, download_name="MBBP_portal_export.xlsx")


if __name__ == "__main__":
    app.run(debug=True)
