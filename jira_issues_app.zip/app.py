import truststore
truststore.inject_into_ssl()  # use the Windows certificate store (corporate CA)

import os, io, time, requests
import pandas as pd
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, send_file

load_dotenv()

SITE = "https://mercedes-benz-pace.atlassian.net"
AUTH = (os.environ["ATLASSIAN_EMAIL"], os.environ["ATLASSIAN_API_TOKEN"])

PROJECTS = ["FPM", "SAC", "TAFM"]
JQL = f"project in ({', '.join(PROJECTS)}) ORDER BY created DESC"
FIELDS = "summary,issuetype,status,priority,reporter,assignee,created,updated,duedate,project"
CACHE_MINUTES = 10  # reuse the data for 10 minutes instead of asking Jira on every page load

# If Jira is slow or a request fails, try again up to 3 times
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=Retry(total=3, backoff_factor=2)))

app = Flask(__name__)
cache = {"rows": [], "time": 0}


def get_rows():
    # Use the saved data if it is still fresh
    if cache["rows"] and time.time() - cache["time"] < CACHE_MINUTES * 60:
        return cache["rows"]

    url = f"{SITE}/rest/api/3/search/jql"
    params = {"jql": JQL, "fields": FIELDS, "maxResults": 100}

    # 1. Get all issues, page by page, keeping only the important fields
    rows = []
    while True:
        r = session.get(url, headers={"Accept": "application/json"}, auth=AUTH, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()

        for issue in data["issues"]:
            f = issue["fields"]
            rows.append({
                "Key": issue["key"],
                "Summary": f["summary"],
                "Type": f["issuetype"]["name"],
                "Status": f["status"]["name"],
                "Priority": (f["priority"] or {}).get("name", ""),
                "Project": f["project"]["key"],
                "Reporter": (f["reporter"] or {}).get("displayName", ""),
                "Reporter email": (f["reporter"] or {}).get("emailAddress", ""),
                "Assignee": (f["assignee"] or {}).get("displayName", "Unassigned"),
                "Created": f["created"][:10],
                "Updated": f["updated"][:10],
                "Due date": f["duedate"] or "",
            })

        if data.get("isLast", True):
            break
        params["nextPageToken"] = data["nextPageToken"]

    # 2. Save for next time
    cache["rows"], cache["time"] = rows, time.time()
    return rows


@app.route("/")
def index():
    if request.args.get("refresh"):  # "Refresh" button: forget the saved data
        cache["time"] = 0
        return redirect("/")
    rows = get_rows()
    columns = list(rows[0]) if rows else []  # column order: Key, Summary, Type, ...
    return render_template("index.html", rows=rows, columns=columns, site=SITE, projects=PROJECTS)


@app.route("/export")
def export():
    file = io.BytesIO()
    pd.DataFrame(get_rows()).to_excel(file, index=False)
    file.seek(0)
    return send_file(file, download_name="jira_issues.xlsx", as_attachment=True)


if __name__ == "__main__":
    app.run(port=5000, debug=True)
