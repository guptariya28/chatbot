# excel_reader.py
# STEP 1: Read the demand list from Excel and give it to the portal.
# This file only READS the Excel. It never changes it.

import warnings
import pandas as pd
from openpyxl import load_workbook

# Hide the harmless "Data Validation" warning from openpyxl
warnings.filterwarnings("ignore")

EXCEL_FILE = "MBBP26_Apr_V1.xlsx"
SHEET_NAME = "MBBP_2026_09Apr"
HEADER_ROW = 3          # column names are in Excel row 4 (pandas counts from 0)


def load_demands():
    # 1. Read the sheet
    data = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, header=HEADER_ROW)

    # 2. Keep only real items (rows that have an SI NO)
    data = data[data["SI NO"].notna()]

    # 3. Show SI NO as 1, 2, 3 instead of 1.0, 2.0, 3.0
    data["SI NO"] = data["SI NO"].astype(int)

    # 4. Add our own unique id (SI NO repeats, so we can't use it)
    data.insert(0, "id", range(1, len(data) + 1))

    # 5. Empty cells: NaN -> "" (empty text)
    data = data.fillna("")

    # 6. Turn the table into a list of rows
    rows = data.to_dict(orient="records")

    return rows


# Which columns are VISIBLE in the Excel (not hidden, not folded with "+").
# Returns the column names in Excel order, e.g. ["SI NO", "SAP STACK /AI/ 3rd Party tool", ...]
def get_visible_columns():
    # 1. The column names (nrows=0 -> read only the header, no data)
    header = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, header=HEADER_ROW, nrows=0)
    names = list(header.columns)

    # 2. Ask openpyxl which Excel columns are hidden.
    #    A "dimension" describes one column or a range of columns (min to max),
    #    e.g. columns 5 to 10 (E to J) folded together.
    workbook = load_workbook(EXCEL_FILE)
    sheet = workbook[SHEET_NAME]

    hidden_numbers = []
    for dimension in sheet.column_dimensions.values():
        if dimension.hidden and dimension.min:
            for number in range(dimension.min, dimension.max + 1):
                hidden_numbers.append(number)

    # 3. Keep the names whose Excel column is not hidden.
    #    names[0] is Excel column 1 (A), names[1] is column 2 (B), ...
    visible = []
    for position in range(len(names)):
        excel_number = position + 1
        if excel_number not in hidden_numbers:
            visible.append(names[position])

    return visible


# ------------------------------------------------------------
# Runs ONLY when you run this file directly:  python excel_reader.py
# ------------------------------------------------------------
if __name__ == "__main__":
    demands = load_demands()
    print("Items loaded:", len(demands))
    print("Columns per item:", len(demands[0]))

    print()
    print("Columns visible in Excel:")
    for name in get_visible_columns():
        print("  ", name)
