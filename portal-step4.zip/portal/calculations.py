# calculations.py
# All the filtering and math of the portal.
# Plain Python only - no Flask in this file.


# ============================================================
# Excel column names we use (exactly as they are in the Excel)
# ============================================================
SI_NO_COLUMN = "SI NO"
REQUIREMENT_COLUMN = "Requirement/CR/New Demand Item"
JIRA_COLUMN = "JIRA ID"
TOPIC_COLUMN = "Topic Group"
AOP_COLUMN = "AOP/NON-AOP"
IO_LEAD_COLUMN = "IO Lead"
E4_COLUMN = "Business E4 manager"
MODULE_COLUMN = "Module.1"                          # tech module (FICO, LOGISTICS...)
CONFIRMATION_COLUMN = "Business Confirmation"
DEV_COLUMN = "Development (Man-Days)"
EFFORT_COLUMN = "Total Effort (Man-Days)"
DELIVERY_COLUMN = "Actual Date/ Planned Del. Date"
MODE_COLUMN = "Can this Object be delivered as Inhouse or can it be deliverd as MS/MT PKG?"
PACKAGE_COLUMN = "IS PACKAGE(Y/N)"

# Our own column, only for Non-AOP requests raised in the portal
REQUEST_STATUS_COLUMN = "Request Status"


# The filter dropdowns used on the Dashboard and the Register.
# "name" is the name in the web address, e.g. /register?io_lead=Ravi S
# "label" is the small title shown above the dropdown.
FILTERS = [
    {"name": "io_lead", "column": IO_LEAD_COLUMN, "label": "IO Lead", "all_text": "All"},
    {"name": "e4_manager", "column": E4_COLUMN, "label": "Business E4 Manager", "all_text": "All"},
    {"name": "tech_module", "column": MODULE_COLUMN, "label": "Tech Module", "all_text": "All"},
    {"name": "confirmation", "column": CONFIRMATION_COLUMN, "label": "Business Confirmation", "all_text": "All"},
    {"name": "aop", "column": AOP_COLUMN, "label": "AOP / Non-AOP", "all_text": "All"},
]


# ============================================================
# Small helpers
# ============================================================

# "20" -> 20.0,   "" -> 0,   "TBD" -> 0
def to_number(value):
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0


# Any value -> text without spaces at the start and end
def clean_text(value):
    return str(value).strip()


# True if two texts are the same, ignoring capitals and extra spaces.
# "Must to have " and "Must to Have" -> True   (Excel pivots work like this)
def same_text(first, second):
    return clean_text(first).lower() == clean_text(second).lower()


# Finds a column whose name starts with some text.
# Used for "Funtional Effort \n(Man-Days)" which has a line break in its name.
def find_column(row, starts_with):
    for column in row:
        if column.startswith(starts_with) and not column.endswith(".1"):
            return column
    return ""


# All different values of one column, A to Z.
# "Must to Have" and "Must to have" count as ONE value.
def get_unique_values(rows, column):
    values = []
    seen = []
    for row in rows:
        value = clean_text(row.get(column, ""))
        if value == "":
            continue
        if value.lower() in seen:
            continue
        seen.append(value.lower())
        values.append(value)
    values.sort()
    return values


# Columns that hold man-days (shown as number boxes when editing)
def is_number_column(column):
    return "(Man-Days)" in column


def is_package(row):
    return clean_text(row.get(MODE_COLUMN, "")).upper() == "MS/MT PKG"


def is_must_have(row):
    return same_text(row.get(CONFIRMATION_COLUMN, ""), "Must to Have")


# Non-AOP requests that are waiting or rejected don't count anywhere
def is_not_approved(row):
    status = row.get(REQUEST_STATUS_COLUMN, "")
    return status == "Pending review" or status == "Rejected"


# The delivery date text, or "(blank)" when empty
def get_delivery_value(row):
    value = clean_text(row.get(DELIVERY_COLUMN, ""))
    if value == "":
        return "(blank)"
    return value


# The tech module text, or "(blank)" when empty
def get_module_value(row):
    value = clean_text(row.get(MODULE_COLUMN, ""))
    if value == "":
        return "(blank)"
    return value


# Used to sort rows by effort (biggest first)
def get_effort(row):
    return to_number(row.get(EFFORT_COLUMN, ""))


# ============================================================
# Filters (Dashboard + Register)
# ============================================================

# Reads the chosen filters from the web address.
# /register?io_lead=Ravi S&search=PR  ->  {"io_lead": "Ravi S", ..., "search": "PR"}
def read_filters(args):
    chosen = {}
    for filter_info in FILTERS:
        chosen[filter_info["name"]] = args.get(filter_info["name"], "")
    chosen["search"] = args.get("search", "")
    return chosen


# Keeps only the rows that match the chosen filters and search text
def apply_filters(rows, chosen):
    search_text = chosen["search"].lower().strip()
    result = []

    for row in rows:
        keep = True

        for filter_info in FILTERS:
            chosen_value = chosen[filter_info["name"]]
            if chosen_value != "":
                if not same_text(row.get(filter_info["column"], ""), chosen_value):
                    keep = False

        if search_text != "":
            row_text = (
                str(row.get(REQUIREMENT_COLUMN, "")) + " "
                + str(row.get(JIRA_COLUMN, "")) + " "
                + str(row.get(TOPIC_COLUMN, "")) + " "
                + str(row.get(SI_NO_COLUMN, ""))
            ).lower()
            if search_text not in row_text:
                keep = False

        if keep:
            result.append(row)

    return result


# The options for every filter dropdown
def get_filter_options(rows):
    options = {}
    for filter_info in FILTERS:
        options[filter_info["name"]] = get_unique_values(rows, filter_info["column"])
    return options


# ============================================================
# Grouping (like an Excel pivot table)
# ============================================================

# Groups rows by one column and adds them up.
# measure = what the bar shows: "count", "man_days" or "fte"
#
# Result, one item per group, biggest first:
#   {"label": "Ravi S", "count": 70, "jira_count": 52, "man_days": 1530,
#    "packages": 13, "fte": 9.0, "value": 70, "value_text": "70", "percent": 100}
def group_rows(rows, column, man_days_per_fte, measure):
    groups = {}   # key = label in small letters, so "Must to have" and "Must to Have" join

    for row in rows:
        label = clean_text(row.get(column, ""))
        if label == "":
            label = "(blank)"
        key = label.lower()

        if key not in groups:
            groups[key] = {"label": label, "count": 0, "jira_count": 0, "man_days": 0, "packages": 0}

        group = groups[key]
        group["count"] = group["count"] + 1
        group["man_days"] = group["man_days"] + get_effort(row)
        if clean_text(row.get(JIRA_COLUMN, "")) != "":
            group["jira_count"] = group["jira_count"] + 1
        if is_package(row):
            group["packages"] = group["packages"] + 1

    group_list = list(groups.values())

    # FTE and the value for the bar
    for group in group_list:
        group["fte"] = round(group["man_days"] / man_days_per_fte, 2)
        group["value"] = group[measure]
        if measure == "fte":
            group["value_text"] = "{:.2f}".format(group["value"])
        else:
            group["value_text"] = "{:,.0f}".format(group["value"])

    group_list.sort(key=get_group_value, reverse=True)

    # Bar length in % (the biggest group = 100%)
    biggest = 0
    if len(group_list) > 0:
        biggest = group_list[0]["value"]
    for group in group_list:
        if biggest > 0:
            group["percent"] = round(group["value"] / biggest * 100)
        else:
            group["percent"] = 0

    # Share of the total in % (used by pie and donut charts)
    total = 0
    for group in group_list:
        total = total + group["value"]
    for group in group_list:
        if total > 0:
            group["share"] = round(group["value"] / total * 100, 1)
        else:
            group["share"] = 0

    # Every group gets its own color.
    # Known values always get the SAME color (Must to Have is always blue, (blank) always grey).
    # Other values take the next color from the list.
    for number in range(len(group_list)):
        key = group_list[number]["label"].lower()
        if key in FIXED_COLORS:
            group_list[number]["color"] = FIXED_COLORS[key]
        else:
            group_list[number]["color"] = CHART_COLORS[number % len(CHART_COLORS)]

    return group_list


def get_group_value(group):
    return group["value"]


# Colors of the bars and slices (one per group, then they repeat)
CHART_COLORS = ["#118DFF", "#12239E", "#E66C37", "#6B007B", "#E044A7", "#744EC2", "#D9B300", "#C8CDD3"]

# Colors that belong to a meaning (the key is the value in small letters)
FIXED_COLORS = {
    "must to have": "#118DFF",   # blue
    "good to have": "#12239E",   # navy
    "not required": "#E66C37",   # orange
    "inhouse": "#12239E",        # navy
    "in-house": "#12239E",       # navy
    "ms/mt pkg": "#E044A7",      # pink
    "(blank)": "#C8CDD3",        # grey
}


# ============================================================
# Delivery timeline (month or quarter)
# The Excel column has free text: "Mar' 26", "Aug'26", "June'26", "Q3 2026", "WIP", "Drop" ...
# ============================================================
MONTH_NUMBERS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
                 "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


# Reads one delivery text and gives back 3 things:
#   month label, quarter label, and a number used to sort by time.
#   "Mar' 26"  -> ("Mar'26", "Q1'26", 2603)
#   "June'26"  -> ("Jun'26", "Q2'26", 2606)
#   "Q3 2026"  -> ("Q3'26",  "Q3'26", 2609.5)   (no month known, so it stays a quarter)
#   "WIP"      -> ("WIP",    "WIP",   90000)    (not a date: goes at the end)
def read_delivery(text):
    if text == "(blank)":
        return ("(blank)", "(blank)", 99999)

    short = text.lower().replace(" ", "").replace("'", "")
    year = short[-2:]                       # the last 2 characters: "26"
    if not year.isdigit():
        return (text, text, 90000)

    # A month name? ("mar26", "june26", "aug26")
    for name in MONTH_NUMBERS:
        if short.startswith(name):
            month = MONTH_NUMBERS[name]
            quarter = (month - 1) // 3 + 1     # 1-3 -> Q1, 4-6 -> Q2, 7-9 -> Q3, 10-12 -> Q4
            month_label = MONTH_NAMES[month - 1] + "'" + year
            quarter_label = "Q" + str(quarter) + "'" + year
            return (month_label, quarter_label, int(year) * 100 + month)

    # A quarter? ("q32026", "q326")
    if short.startswith("q") and short[1].isdigit():
        quarter = int(short[1])
        label = "Q" + str(quarter) + "'" + year
        return (label, label, int(year) * 100 + quarter * 3 + 0.5)

    return (text, text, 90000)


# Groups rows by delivery month or quarter, sorted by time (not by size).
# period = "month" or "quarter".  Rows without a date are left out.
def group_by_delivery(rows, man_days_per_fte, period):
    period_rows = []
    sort_numbers = {}

    for row in rows:
        delivery = get_delivery_value(row)
        if delivery == "(blank)":
            continue

        month_label, quarter_label, sort_number = read_delivery(delivery)

        # Month view shows only real months.
        # "Q3 2026", "WIP" and "Drop" have no month (their month and quarter label are the same),
        # so they are shown only in the Quarter view.
        if period != "quarter" and month_label == quarter_label:
            continue

        if period == "quarter":
            label = quarter_label
        else:
            label = month_label

        # A copy of the row with one extra column, so group_rows() can group on it
        copy = dict(row)
        copy["Delivery period"] = label
        period_rows.append(copy)

        if label not in sort_numbers or sort_number < sort_numbers[label]:
            sort_numbers[label] = sort_number

    groups = group_rows(period_rows, "Delivery period", man_days_per_fte, "count")
    for group in groups:
        group["sort_number"] = sort_numbers.get(group["label"], 99999)
    groups.sort(key=get_sort_number)
    return groups


def get_sort_number(group):
    return group["sort_number"]


# How many rows have no delivery date
def count_without_delivery(rows):
    count = 0
    for row in rows:
        if get_delivery_value(row) == "(blank)":
            count = count + 1
    return count


# Builds the CSS that draws a pie: each group is a colored slice.
# Example with 2 groups (75% and 25%):
#   "conic-gradient(#2f6fb5 0% 75%, #d9622b 75% 100%)"
# conic-gradient = colors going around a circle, like the hands of a clock.
def make_pie_style(groups):
    parts = []
    start = 0
    for group in groups:
        end = start + group["share"]
        parts.append(group["color"] + " " + str(round(start, 1)) + "% " + str(round(end, 1)) + "%")
        start = end
    if len(parts) == 0:
        return "conic-gradient(#e6eaf0 0% 100%)"
    return "conic-gradient(" + ", ".join(parts) + ")"


# Adds up a list of groups (for the "Grand Total" row)
def get_totals(groups, man_days_per_fte):
    totals = {"count": 0, "jira_count": 0, "man_days": 0, "packages": 0}
    for group in groups:
        totals["count"] = totals["count"] + group["count"]
        totals["jira_count"] = totals["jira_count"] + group["jira_count"]
        totals["man_days"] = totals["man_days"] + group["man_days"]
        totals["packages"] = totals["packages"] + group["packages"]
    totals["fte"] = round(totals["man_days"] / man_days_per_fte, 2)
    return totals


# ============================================================
# FTE Summary (the MBBP_Summary sheet)
# ============================================================

# Delivery dates BEFORE the plan period (Apr-Dec 2026):
# anything in 2025, and Jan / Feb / Mar 2026.
# "Mar' 26" -> True,  "Dec' 25" -> True,  "Aug'26" -> False,  "Q3 2026" -> False
def is_before_period(text):
    short = text.lower().replace(" ", "").replace("'", "")
    if "25" in short:
        return True
    if short.startswith("jan") and "26" in short:
        return True
    if short.startswith("feb") and "26" in short:
        return True
    if short.startswith("mar") and "26" in short:
        return True
    return False


# The first settings when the app starts.
# These are the same choices as the ticks in the Excel pivot filters.
def make_default_settings(rows):
    all_modules = []
    all_deliveries = []
    for row in rows:
        module = get_module_value(row)
        if module not in all_modules:
            all_modules.append(module)
        delivery = get_delivery_value(row)
        if delivery not in all_deliveries:
            all_deliveries.append(delivery)
    all_modules.sort()
    all_deliveries.sort()

    # Modules: everything except TRAVEL, SAC and empty
    included_modules = []
    for module in all_modules:
        if module.upper() not in ["TRAVEL", "SAC", "(BLANK)"]:
            included_modules.append(module)

    # Delivery dates: everything except "Drop" and dates before April 2026
    included_deliveries = []
    for delivery in all_deliveries:
        if delivery.lower() == "drop":
            continue
        if is_before_period(delivery):
            continue
        included_deliveries.append(delivery)

    settings = {
        "man_days_per_fte": 170,
        "available_man_days": 0,
        "all_modules": all_modules,
        "included_modules": included_modules,
        "all_deliveries": all_deliveries,
        "included_deliveries": included_deliveries,
    }
    return settings


# Is this row counted as "required work"?  (= the Excel pivot filters)
def is_in_scope(row, settings):
    if not is_must_have(row):
        return False
    if is_not_approved(row):
        return False
    if get_module_value(row) not in settings["included_modules"]:
        return False
    if get_delivery_value(row) not in settings["included_deliveries"]:
        return False
    return True


def calculate_summary(rows, settings):
    per_fte = settings["man_days_per_fte"]

    scope_rows = []        # required work
    package_rows = []      # required work that MS/MT can deliver
    before_rows = []       # Must to Have, delivered before April 2026
    dropped_rows = []      # Must to Have, marked "Drop"

    for row in rows:
        if is_in_scope(row, settings):
            scope_rows.append(row)
            if is_package(row):
                package_rows.append(row)

        if is_must_have(row) and get_module_value(row) in settings["included_modules"]:
            delivery = get_delivery_value(row)
            if is_before_period(delivery):
                before_rows.append(row)
            if delivery.lower() == "drop":
                dropped_rows.append(row)

    required_man_days = 0
    for row in scope_rows:
        required_man_days = required_man_days + get_effort(row)

    package_man_days = 0
    for row in package_rows:
        package_man_days = package_man_days + get_effort(row)

    before_man_days = 0
    for row in before_rows:
        before_man_days = before_man_days + get_effort(row)

    dropped_man_days = 0
    for row in dropped_rows:
        dropped_man_days = dropped_man_days + get_effort(row)

    available_man_days = settings["available_man_days"]

    summary = {
        "per_fte": per_fte,
        "scope_count": len(scope_rows),

        "required_man_days": required_man_days,
        "required_fte": round(required_man_days / per_fte, 2),

        "available_man_days": available_man_days,
        "available_fte": round(available_man_days / per_fte, 2),

        "deficit_man_days": available_man_days - required_man_days,
        "deficit_fte": round((available_man_days - required_man_days) / per_fte, 2),

        "package_count": len(package_rows),
        "package_man_days": package_man_days,
        "package_fte": round(package_man_days / per_fte, 2),

        "before_count": len(before_rows),
        "before_man_days": before_man_days,
        "before_fte": round(before_man_days / per_fte, 2),

        "dropped_count": len(dropped_rows),
        "dropped_man_days": dropped_man_days,
        "dropped_fte": round(dropped_man_days / per_fte, 2),

        "scope_rows": scope_rows,
        "package_rows": package_rows,
    }

    summary["deficit_after_package_fte"] = round(summary["deficit_fte"] + summary["package_fte"], 2)

    return summary
